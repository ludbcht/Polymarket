"""Script CLI : récupère les marchés actifs Polymarket et les enregistre en base.

À exécuter périodiquement (ex: cron toutes les 5 minutes) pour constituer un historique
réel exploitable par le moteur de replay et le pipeline ML.

Si l'API Polymarket est inaccessible (réseau, rate limit), le script journalise l'erreur
et s'arrête proprement sans jamais générer de fausses données réelles.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import typer

from polyquant.data.database import get_database
from polyquant.data.polymarket_client import PolymarketAPIError, PolymarketClient
from polyquant.logging_config import get_logger

app = typer.Typer(add_completion=False)
logger = get_logger(__name__)


@app.command()
def main(limit: int = typer.Option(200, help="Nombre maximal de marchés à récupérer")) -> None:
    db = get_database()

    with PolymarketClient() as client:
        try:
            states = client.fetch_market_states(limit=limit)
        except PolymarketAPIError as exc:
            typer.echo(f"Erreur lors de la récupération des données Polymarket: {exc}", err=True)
            raise typer.Exit(code=1) from exc

    if not states:
        typer.echo("Aucun marché récupéré (réponse vide).")
        raise typer.Exit(code=1)

    n_saved = db.save_snapshots(states)
    typer.echo(f"{n_saved} snapshots de marché enregistrés en base.")


if __name__ == "__main__":
    app()

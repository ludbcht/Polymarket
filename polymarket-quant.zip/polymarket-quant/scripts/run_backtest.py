"""Script CLI : lance un backtest complet sur les données disponibles en base.

Usage:
    python scripts/run_backtest.py --n-markets 15 --n-points 300 --seed 7
    python scripts/run_backtest.py --use-real-data   # utilise les données Polymarket réelles
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import typer

from polyquant.backtest.engine import BacktestConfig, BacktestEngine
from polyquant.config import get_settings
from polyquant.data.database import get_database
from polyquant.data.replay import HistoricalReplayEngine
from polyquant.data.synthetic import generate_synthetic_universe
from polyquant.logging_config import get_logger
from polyquant.ml.pipeline import MLPredictor
from polyquant.strategies import default_strategy_registry

app = typer.Typer(add_completion=False)
logger = get_logger(__name__)


@app.command()
def main(
    n_markets: int = typer.Option(15, help="Nombre de marchés synthétiques à générer (mode démo)"),
    n_points: int = typer.Option(300, help="Nombre de cycles temporels à simuler"),
    seed: int = typer.Option(7, help="Seed aléatoire pour la reproductibilité"),
    use_real_data: bool = typer.Option(False, help="Utilise les données déjà présentes en base au lieu d'en générer"),
    use_ml: bool = typer.Option(False, help="Active la prédiction ML (nécessite un modèle entraîné au préalable)"),
    capital: float = typer.Option(None, help="Capital initial en euros (défaut: valeur de configuration)"),
) -> None:
    settings = get_settings()
    db = get_database()

    if not use_real_data:
        typer.echo(f"Génération de {n_markets} marchés synthétiques ({n_points} points, seed={seed})...")
        states = generate_synthetic_universe(n_markets=n_markets, n_points=n_points, seed=seed, shock_probability=0.03)
        db.save_snapshots(states)

    cycles = HistoricalReplayEngine(db).load()
    typer.echo(f"{len(cycles)} cycles chargés depuis la base.")

    ml_predictor = None
    if use_ml:
        typer.echo("Entraînement du modèle ML sur les données disponibles...")
        ml_predictor, report = MLPredictor.train_from_database(db)
        typer.echo(f"Meilleur modèle: {report.best_model_name} ({report.n_samples} échantillons)")

    config = BacktestConfig(
        initial_capital=capital or settings.initial_capital_eur,
        strategies=default_strategy_registry(),
        use_ml=use_ml,
    )
    engine = BacktestEngine(config, ml_predictor=ml_predictor)
    result = engine.run(cycles)

    typer.echo("\n=== Résultat du backtest ===")
    for key, value in result.performance.to_dict().items():
        typer.echo(f"{key}: {value}")
    typer.echo(f"\nSignaux générés: {result.n_signals_generated} | Signaux tradés: {result.n_signals_traded}")


if __name__ == "__main__":
    app()

"""Script CLI : lance la boucle de paper trading en continu (ou pour un nombre de cycles borné).

Usage:
    python scripts/run_paper_trading.py --max-cycles 12   # 12 cycles puis arrêt
    python scripts/run_paper_trading.py                    # boucle infinie (Ctrl+C pour arrêter)
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import typer

from polyquant.config import get_settings
from polyquant.data.database import get_database
from polyquant.logging_config import get_logger
from polyquant.ml.pipeline import MLPredictor
from polyquant.paper_trading.engine import PaperTradingConfig, PaperTradingEngine

app = typer.Typer(add_completion=False)
logger = get_logger(__name__)


@app.command()
def main(
    max_cycles: int = typer.Option(None, help="Nombre de cycles avant arrêt (défaut: infini)"),
    use_ml: bool = typer.Option(False, help="Active la prédiction ML (nécessite un modèle entraîné)"),
    capital: float = typer.Option(None, help="Capital initial en euros"),
) -> None:
    settings = get_settings()
    db = get_database()

    ml_predictor = None
    if use_ml:
        typer.echo("Entraînement du modèle ML sur l'historique disponible...")
        ml_predictor, report = MLPredictor.train_from_database(db)
        typer.echo(f"Modèle sélectionné: {report.best_model_name}")

    config = PaperTradingConfig(initial_capital=capital or settings.initial_capital_eur)
    engine = PaperTradingEngine(config=config, db=db, ml_predictor=ml_predictor)

    typer.echo(f"Démarrage du paper trading (cycle={engine.cycle_minutes} min, run_id={engine.run_id})")
    typer.echo("Aucun ordre réel ne sera jamais envoyé. Ctrl+C pour arrêter.")

    try:
        engine.run_loop(max_cycles=max_cycles)
    except KeyboardInterrupt:
        typer.echo("\nArrêt demandé par l'utilisateur.")

    typer.echo(f"\nCapital final (cash, hors positions ouvertes non valorisées): {engine.portfolio.cash:.2f} €")
    typer.echo(f"Nombre de positions ouvertes restantes: {len(engine.portfolio.positions)}")
    typer.echo(f"Nombre de trades clôturés: {len(engine.portfolio.closed_trades)}")


if __name__ == "__main__":
    app()

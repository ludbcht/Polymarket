"""Moteur de backtest : rejoue l'historique cycle par cycle et applique le pipeline complet
signal -> score -> risque -> exécution -> portefeuille.

Aucune position n'est ouverte sans signal ET score au-dessus du seuil : le système ne
« parie pas au hasard toutes les 5 minutes ».
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field

from polyquant.backtest.execution import ExecutionSimulator
from polyquant.backtest.metrics import PerformanceReport, generate_performance_report
from polyquant.backtest.portfolio import Portfolio
from polyquant.data.models import OrderAction, Side
from polyquant.data.replay import ReplayCycle
from polyquant.decision.scorer import DecisionScorer
from polyquant.logging_config import get_logger
from polyquant.ml.pipeline import MLPredictor
from polyquant.risk.manager import RiskManager
from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal

logger = get_logger(__name__)

DEFAULT_HISTORY_WINDOW = 60


@dataclass(slots=True)
class BacktestConfig:
    initial_capital: float = 100.0
    history_window: int = DEFAULT_HISTORY_WINDOW
    strategies: list[Strategy] = field(default_factory=list)
    use_ml: bool = True


@dataclass(slots=True)
class BacktestResult:
    run_id: str
    performance: PerformanceReport
    portfolio: Portfolio
    n_signals_generated: int
    n_signals_traded: int


class BacktestEngine:
    """Exécute une simulation complète sur une séquence de cycles de replay historique."""

    def __init__(
        self,
        config: BacktestConfig,
        scorer: DecisionScorer | None = None,
        risk_manager: RiskManager | None = None,
        execution_simulator: ExecutionSimulator | None = None,
        ml_predictor: MLPredictor | None = None,
    ) -> None:
        self.config = config
        self.scorer = scorer or DecisionScorer()
        self.risk_manager = risk_manager or RiskManager()
        self.execution = execution_simulator or ExecutionSimulator()
        self.ml_predictor = ml_predictor if config.use_ml else None
        self._histories: dict[str, MarketHistory] = {}
        self._n_signals_generated = 0
        self._n_signals_traded = 0

    def _update_history(self, cycle: ReplayCycle) -> None:
        for market_id, state in cycle.markets.items():
            history = self._histories.get(market_id, MarketHistory(market_id=market_id, states=[]))
            new_states = [*history.states, state][-self.config.history_window :]
            self._histories[market_id] = MarketHistory(market_id=market_id, states=new_states)

    def _collect_signals(self, market_id: str) -> list[StrategySignal]:
        history = self._histories[market_id]
        signals: list[StrategySignal] = []
        for strategy in self.config.strategies:
            try:
                signal = strategy.generate_signal(history)
            except Exception:  # noqa: BLE001 - une stratégie ne doit jamais interrompre le run
                logger.exception("erreur_strategie", strategy=strategy.name, market_id=market_id)
                continue
            if signal is not None:
                signals.append(signal)
        return signals

    @staticmethod
    def _mark_to_market_prices(portfolio: Portfolio, cycle: ReplayCycle) -> dict[str, float]:
        """Construit le dict de prix courants utilisé pour valoriser le portefeuille.

        Pour chaque position ouverte, le prix pertinent dépend du côté détenu (YES ou NO) :
        une position NO doit être valorisée au prix_no, pas au prix_yes du marché.
        """
        prices: dict[str, float] = {}
        for market_id, state in cycle.markets.items():
            position = portfolio.positions.get(market_id)
            if position is not None:
                prices[market_id] = state.price_yes if position.side == Side.YES else state.price_no
            else:
                prices[market_id] = state.price_yes
        return prices

    def _manage_exits(self, portfolio: Portfolio, cycle: ReplayCycle, run_id: str) -> None:
        current_prices = self._mark_to_market_prices(portfolio, cycle)
        for market_id in list(portfolio.positions.keys()):
            state = cycle.markets.get(market_id)
            if state is None:
                continue
            position = portfolio.positions[market_id]
            current_price = state.price_yes if position.side == Side.YES else state.price_no
            exit_reason = self.risk_manager.should_exit_on_stops(
                current_price, position.stop_loss_price, position.take_profit_price
            )
            if exit_reason is None:
                continue
            result = self.execution.simulate_market_order(
                state, position.side, OrderAction.SELL, position.quantity * current_price
            )
            if result.rejected:
                continue
            portfolio.close_position(market_id, result.executed_price, result.fee_eur, state.timestamp, exit_reason)
        portfolio.record_equity(cycle.timestamp, current_prices)

    def _manage_entries(self, portfolio: Portfolio, cycle: ReplayCycle) -> None:
        current_prices = self._mark_to_market_prices(portfolio, cycle)
        for market_id, state in cycle.markets.items():
            if market_id not in self._histories:
                continue
            signals = self._collect_signals(market_id)
            if not signals:
                continue
            self._n_signals_generated += 1

            ml_probability = None
            if self.ml_predictor is not None:
                ml_probability = self.ml_predictor.predict_proba(self._histories[market_id])

            opportunity = self.scorer.score(state, signals, ml_probability)
            if opportunity is None or not opportunity.tradable:
                continue

            history = self._histories[market_id]
            volatility = history.realized_volatility(15)
            entry_price = state.price_yes if opportunity.side == Side.YES else state.price_no

            sizing = self.risk_manager.evaluate_position_size(
                portfolio, state, entry_price, opportunity.score, current_prices, volatility
            )
            if not sizing.approved:
                continue

            result = self.execution.simulate_market_order(
                state, opportunity.side, OrderAction.BUY, sizing.notional_eur
            )
            if result.rejected or result.quantity <= 0:
                continue

            strategy_names = ",".join(opportunity.contributing_strategies) or "inconnue"
            portfolio.open_position(
                market_id=market_id,
                side=opportunity.side,
                quantity=result.quantity,
                entry_price=result.executed_price,
                notional_eur=sizing.notional_eur,
                fee_eur=result.fee_eur,
                timestamp=state.timestamp,
                strategy=strategy_names,
                stop_loss_price=sizing.stop_loss_price,
                take_profit_price=sizing.take_profit_price,
            )
            self._n_signals_traded += 1

    def run(self, cycles: list[ReplayCycle]) -> BacktestResult:
        run_id = str(uuid.uuid4())[:8]
        portfolio = Portfolio(initial_capital=self.config.initial_capital)

        logger.info("backtest_demarre", run_id=run_id, n_cycles=len(cycles), capital=self.config.initial_capital)

        for cycle in cycles:
            self._update_history(cycle)
            self._manage_exits(portfolio, cycle, run_id)
            self._manage_entries(portfolio, cycle)

        # Clôture forcée de toutes les positions restantes à la fin du backtest, au dernier prix connu.
        if cycles:
            last_cycle = cycles[-1]
            for market_id in list(portfolio.positions.keys()):
                state = last_cycle.markets.get(market_id)
                if state is None:
                    continue
                position = portfolio.positions[market_id]
                current_price = state.price_yes if position.side == Side.YES else state.price_no
                result = self.execution.simulate_market_order(
                    state, position.side, OrderAction.SELL, position.quantity * current_price
                )
                if not result.rejected:
                    portfolio.close_position(
                        market_id, result.executed_price, result.fee_eur, state.timestamp, "cloture_fin_backtest"
                    )

        performance = generate_performance_report(
            self.config.initial_capital,
            portfolio.equity_curve or [(cycles[0].timestamp if cycles else None, self.config.initial_capital)],  # type: ignore[list-item]
            portfolio.closed_trades,
            portfolio.total_fees_paid,
        )

        logger.info(
            "backtest_termine",
            run_id=run_id,
            rendement_pct=round(performance.total_return_pct, 2),
            sharpe=round(performance.sharpe_ratio, 3),
            n_trades=performance.n_trades,
            signaux_generes=self._n_signals_generated,
            signaux_tradés=self._n_signals_traded,
        )

        return BacktestResult(
            run_id=run_id,
            performance=performance,
            portfolio=portfolio,
            n_signals_generated=self._n_signals_generated,
            n_signals_traded=self._n_signals_traded,
        )

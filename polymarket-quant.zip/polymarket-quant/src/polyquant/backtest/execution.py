"""Simulation d'exécution d'ordres : frais, slippage et impact de liquidité limitée.

Aucun ordre réel n'est jamais envoyé : ce module calcule uniquement le prix d'exécution
simulé et les coûts associés, à partir de l'état de marché observé.
"""

from __future__ import annotations

from dataclasses import dataclass

from polyquant.config import get_settings
from polyquant.data.models import MarketState, OrderAction, Side


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    """Résultat d'une simulation d'exécution d'ordre."""

    requested_price: float
    executed_price: float
    quantity: float
    fee_eur: float
    slippage_eur: float
    total_cost_eur: float
    rejected: bool = False
    rejection_reason: str | None = None

    @property
    def total_cost_with_fees(self) -> float:
        return self.total_cost_eur + self.fee_eur


class ExecutionSimulator:
    """Simule l'exécution d'un ordre en tenant compte des frais, du slippage et de la liquidité."""

    def __init__(
        self,
        taker_fee_bps: float | None = None,
        slippage_bps: float | None = None,
        max_depth_impact: float | None = None,
    ) -> None:
        settings = get_settings()
        self.taker_fee_bps = taker_fee_bps if taker_fee_bps is not None else settings.taker_fee_bps
        self.slippage_bps = slippage_bps if slippage_bps is not None else settings.slippage_bps
        self.max_depth_impact = (
            max_depth_impact if max_depth_impact is not None else settings.max_order_book_depth_impact
        )

    def _reference_price(self, market: MarketState, side: Side) -> float:
        return market.price_yes if side == Side.YES else market.price_no

    def simulate_market_order(
        self,
        market: MarketState,
        side: Side,
        action: OrderAction,
        notional_eur: float,
    ) -> ExecutionResult:
        """Simule un ordre au marché de taille `notional_eur` (en euros de mise)."""
        ref_price = self._reference_price(market, side)
        if ref_price <= 0 or ref_price >= 1:
            return ExecutionResult(
                requested_price=ref_price,
                executed_price=ref_price,
                quantity=0.0,
                fee_eur=0.0,
                slippage_eur=0.0,
                total_cost_eur=0.0,
                rejected=True,
                rejection_reason="prix_hors_bornes",
            )

        # Rejet si l'ordre dépasse une part trop importante de la profondeur disponible
        # (impact de marché jugé trop élevé pour être exécuté proprement).
        depth = max(market.order_book_depth, 1e-6)
        depth_fraction = notional_eur / depth
        if depth_fraction > self.max_depth_impact:
            return ExecutionResult(
                requested_price=ref_price,
                executed_price=ref_price,
                quantity=0.0,
                fee_eur=0.0,
                slippage_eur=0.0,
                total_cost_eur=0.0,
                rejected=True,
                rejection_reason="liquidite_insuffisante",
            )

        # Le slippage croît avec la part de la profondeur consommée (impact de marché non linéaire)
        # et avec le spread observé.
        spread_component = market.spread / 2
        impact_component = (self.slippage_bps / 10_000) * (1 + 3 * depth_fraction)
        slippage_rate = spread_component + impact_component

        direction = 1 if action == OrderAction.BUY else -1
        executed_price = ref_price * (1 + direction * slippage_rate)
        executed_price = max(0.001, min(0.999, executed_price))

        quantity = notional_eur / executed_price
        slippage_eur = abs(executed_price - ref_price) * quantity
        fee_eur = notional_eur * (self.taker_fee_bps / 10_000)

        return ExecutionResult(
            requested_price=ref_price,
            executed_price=executed_price,
            quantity=quantity,
            fee_eur=fee_eur,
            slippage_eur=slippage_eur,
            total_cost_eur=notional_eur,
        )

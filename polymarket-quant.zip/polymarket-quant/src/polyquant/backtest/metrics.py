"""Calcul des métriques de performance à partir de la courbe d'équité et des trades clôturés."""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime

from polyquant.backtest.portfolio import ClosedTrade

TRADING_PERIODS_PER_YEAR = 365 * 24 * 12  # cycles de 5 minutes, 24h/24, 365j/an


@dataclass(frozen=True, slots=True)
class PerformanceReport:
    initial_capital: float
    final_equity: float
    total_return_pct: float
    annualized_return_pct: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown_pct: float
    profit_factor: float
    expectancy_eur: float
    win_rate_pct: float
    n_trades: int
    total_fees_paid: float

    def to_dict(self) -> dict[str, float | int]:
        return {
            "initial_capital": self.initial_capital,
            "final_equity": self.final_equity,
            "total_return_pct": self.total_return_pct,
            "annualized_return_pct": self.annualized_return_pct,
            "sharpe_ratio": self.sharpe_ratio,
            "sortino_ratio": self.sortino_ratio,
            "max_drawdown_pct": self.max_drawdown_pct,
            "profit_factor": self.profit_factor,
            "expectancy_eur": self.expectancy_eur,
            "win_rate_pct": self.win_rate_pct,
            "n_trades": self.n_trades,
            "total_fees_paid": self.total_fees_paid,
        }


def _period_returns(equity_curve: list[tuple[datetime, float]]) -> list[float]:
    returns = []
    for i in range(1, len(equity_curve)):
        prev = equity_curve[i - 1][1]
        curr = equity_curve[i][1]
        if prev > 0:
            returns.append((curr - prev) / prev)
    return returns


def compute_sharpe_ratio(returns: list[float], risk_free_rate: float = 0.0) -> float:
    if len(returns) < 2:
        return 0.0
    mean_excess = sum(returns) / len(returns) - risk_free_rate
    variance = sum((r - sum(returns) / len(returns)) ** 2 for r in returns) / (len(returns) - 1)
    std = math.sqrt(variance)
    if std == 0:
        return 0.0
    return (mean_excess / std) * math.sqrt(TRADING_PERIODS_PER_YEAR)


def compute_sortino_ratio(returns: list[float], risk_free_rate: float = 0.0) -> float:
    if len(returns) < 2:
        return 0.0
    mean_excess = sum(returns) / len(returns) - risk_free_rate
    downside = [min(0.0, r - risk_free_rate) ** 2 for r in returns]
    downside_var = sum(downside) / len(returns)
    downside_std = math.sqrt(downside_var)
    if downside_std == 0:
        return 0.0
    return (mean_excess / downside_std) * math.sqrt(TRADING_PERIODS_PER_YEAR)


def compute_max_drawdown_pct(equity_curve: list[tuple[datetime, float]]) -> float:
    if not equity_curve:
        return 0.0
    peak = equity_curve[0][1]
    max_dd = 0.0
    for _, equity in equity_curve:
        peak = max(peak, equity)
        if peak > 0:
            dd = (peak - equity) / peak
            max_dd = max(max_dd, dd)
    return max_dd * 100


def compute_profit_factor(trades: list[ClosedTrade]) -> float:
    gross_profit = sum(t.realized_pnl for t in trades if t.realized_pnl > 0)
    gross_loss = abs(sum(t.realized_pnl for t in trades if t.realized_pnl < 0))
    if gross_loss == 0:
        return float("inf") if gross_profit > 0 else 0.0
    return gross_profit / gross_loss


def compute_expectancy(trades: list[ClosedTrade]) -> float:
    if not trades:
        return 0.0
    return sum(t.realized_pnl for t in trades) / len(trades)


def compute_win_rate_pct(trades: list[ClosedTrade]) -> float:
    if not trades:
        return 0.0
    wins = sum(1 for t in trades if t.realized_pnl > 0)
    return (wins / len(trades)) * 100


def compute_annualized_return_pct(
    initial_capital: float, final_equity: float, equity_curve: list[tuple[datetime, float]]
) -> float:
    if len(equity_curve) < 2 or initial_capital <= 0:
        return 0.0
    duration = equity_curve[-1][0] - equity_curve[0][0]
    years = duration.total_seconds() / (365.25 * 24 * 3600)
    if years <= 0:
        return 0.0
    total_return = final_equity / initial_capital
    if total_return <= 0:
        return -100.0

    # Sur des durées très courtes (ex: quelques heures de backtest), l'exposant 1/years devient
    # énorme et (total_return ** (1/years)) diverge numériquement même pour un rendement modeste.
    # On calcule donc en log-espace et on plafonne le résultat à une valeur extrême mais finie.
    log_total_return = math.log(total_return)
    exponent = 1 / years
    log_annualized = log_total_return * exponent

    max_log = math.log(1e6)  # plafond: rendement annualisé de +100,000,000 % maximum affichable
    if log_annualized > max_log:
        return 1e8
    if log_annualized < -max_log:
        return -100.0

    return (math.exp(log_annualized) - 1) * 100


def generate_performance_report(
    initial_capital: float,
    equity_curve: list[tuple[datetime, float]],
    closed_trades: list[ClosedTrade],
    total_fees_paid: float,
) -> PerformanceReport:
    final_equity = equity_curve[-1][1] if equity_curve else initial_capital
    returns = _period_returns(equity_curve)

    return PerformanceReport(
        initial_capital=initial_capital,
        final_equity=final_equity,
        total_return_pct=((final_equity - initial_capital) / initial_capital) * 100
        if initial_capital > 0
        else 0.0,
        annualized_return_pct=compute_annualized_return_pct(initial_capital, final_equity, equity_curve),
        sharpe_ratio=compute_sharpe_ratio(returns),
        sortino_ratio=compute_sortino_ratio(returns),
        max_drawdown_pct=compute_max_drawdown_pct(equity_curve),
        profit_factor=compute_profit_factor(closed_trades),
        expectancy_eur=compute_expectancy(closed_trades),
        win_rate_pct=compute_win_rate_pct(closed_trades),
        n_trades=len(closed_trades),
        total_fees_paid=total_fees_paid,
    )

"""Gestion du portefeuille simulé : cash, positions ouvertes, PnL réalisé/latent, exposition."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from polyquant.data.models import Side
from polyquant.logging_config import get_logger

logger = get_logger(__name__)


@dataclass(slots=True)
class Position:
    """Une position ouverte sur un marché (un seul côté YES/NO à la fois par marché)."""

    market_id: str
    side: Side
    quantity: float
    entry_price: float
    entry_timestamp: datetime
    strategy: str
    stop_loss_price: float | None = None
    take_profit_price: float | None = None
    cost_basis_eur: float = 0.0

    def unrealized_pnl(self, current_price: float) -> float:
        return (current_price - self.entry_price) * self.quantity

    def market_value(self, current_price: float) -> float:
        return current_price * self.quantity


@dataclass(slots=True)
class ClosedTrade:
    market_id: str
    side: Side
    strategy: str
    quantity: float
    entry_price: float
    exit_price: float
    entry_timestamp: datetime
    exit_timestamp: datetime
    realized_pnl: float
    fees_paid: float
    exit_reason: str


@dataclass(slots=True)
class Portfolio:
    """Portefeuille simulé : suit le cash, les positions ouvertes et l'historique des trades clôturés."""

    initial_capital: float
    cash: float = field(init=False)
    positions: dict[str, Position] = field(default_factory=dict)
    closed_trades: list[ClosedTrade] = field(default_factory=list)
    equity_curve: list[tuple[datetime, float]] = field(default_factory=list)
    total_fees_paid: float = 0.0

    def __post_init__(self) -> None:
        self.cash = self.initial_capital

    # --- Ouverture / fermeture de position ---

    def can_open_position(self, notional_eur: float, max_positions: int) -> bool:
        if len(self.positions) >= max_positions:
            return False
        return notional_eur <= self.cash

    def open_position(
        self,
        market_id: str,
        side: Side,
        quantity: float,
        entry_price: float,
        notional_eur: float,
        fee_eur: float,
        timestamp: datetime,
        strategy: str,
        stop_loss_price: float | None = None,
        take_profit_price: float | None = None,
    ) -> Position:
        if market_id in self.positions:
            raise ValueError(f"Une position existe déjà sur le marché {market_id}")

        total_debit = notional_eur + fee_eur
        if total_debit > self.cash + 1e-9:
            raise ValueError(
                f"Cash insuffisant: requis={total_debit:.4f}€, disponible={self.cash:.4f}€"
            )

        self.cash -= total_debit
        self.total_fees_paid += fee_eur

        position = Position(
            market_id=market_id,
            side=side,
            quantity=quantity,
            entry_price=entry_price,
            entry_timestamp=timestamp,
            strategy=strategy,
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
            cost_basis_eur=notional_eur,
        )
        self.positions[market_id] = position
        logger.info(
            "position_ouverte",
            market_id=market_id,
            side=side.value,
            quantity=round(quantity, 4),
            prix=round(entry_price, 4),
            notional=round(notional_eur, 2),
        )
        return position

    def close_position(
        self,
        market_id: str,
        exit_price: float,
        fee_eur: float,
        timestamp: datetime,
        reason: str,
    ) -> ClosedTrade:
        position = self.positions.pop(market_id, None)
        if position is None:
            raise ValueError(f"Aucune position ouverte sur le marché {market_id}")

        proceeds = exit_price * position.quantity
        self.cash += proceeds - fee_eur
        self.total_fees_paid += fee_eur

        realized_pnl = (exit_price - position.entry_price) * position.quantity - fee_eur
        trade = ClosedTrade(
            market_id=market_id,
            side=position.side,
            strategy=position.strategy,
            quantity=position.quantity,
            entry_price=position.entry_price,
            exit_price=exit_price,
            entry_timestamp=position.entry_timestamp,
            exit_timestamp=timestamp,
            realized_pnl=realized_pnl,
            fees_paid=fee_eur,
            exit_reason=reason,
        )
        self.closed_trades.append(trade)
        logger.info(
            "position_fermee",
            market_id=market_id,
            pnl=round(realized_pnl, 4),
            raison=reason,
        )
        return trade

    # --- Valorisation ---

    def total_exposure(self, current_prices: dict[str, float]) -> float:
        return sum(
            pos.market_value(current_prices.get(mid, pos.entry_price))
            for mid, pos in self.positions.items()
        )

    def total_equity(self, current_prices: dict[str, float]) -> float:
        return self.cash + self.total_exposure(current_prices)

    def unrealized_pnl_total(self, current_prices: dict[str, float]) -> float:
        return sum(
            pos.unrealized_pnl(current_prices.get(mid, pos.entry_price))
            for mid, pos in self.positions.items()
        )

    def realized_pnl_total(self) -> float:
        return sum(t.realized_pnl for t in self.closed_trades)

    def record_equity(self, timestamp: datetime, current_prices: dict[str, float]) -> None:
        self.equity_curve.append((timestamp, self.total_equity(current_prices)))

"""Configuration centralisée du projet, chargée depuis les variables d'environnement (.env).

Toute la configuration du système passe par ce module. Aucune valeur sensible ou
paramètre métier ne doit être codé en dur ailleurs dans le code.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Paramètres de configuration globaux, validés au démarrage."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- API Polymarket ---
    polymarket_gamma_api_url: str = "https://gamma-api.polymarket.com"
    polymarket_clob_api_url: str = "https://clob.polymarket.com"
    polymarket_api_timeout_seconds: float = 15.0
    polymarket_api_max_retries: int = 3

    # --- Base de données ---
    database_url: str = "sqlite:///data_store/db/polyquant.db"

    # --- Cache ---
    cache_dir: Path = Path("data_store/cache")
    cache_ttl_seconds: int = 60

    # --- Capital ---
    initial_capital_eur: float = 100.0
    base_currency: str = "EUR"

    # --- Exécution (frais / slippage) ---
    taker_fee_bps: float = 200.0
    slippage_bps: float = 50.0
    max_order_book_depth_impact: float = 0.25

    # --- Risque ---
    max_risk_per_position_pct: float = 0.01
    max_total_exposure_pct: float = 0.20
    max_concurrent_positions: int = 5
    stop_loss_pct: float = 0.15
    take_profit_pct: float = 0.30
    volatility_reduction_threshold: float = 0.08

    # --- Moteur de décision ---
    opportunity_score_threshold: float = 0.65
    weight_momentum: float = 0.25
    weight_volume: float = 0.15
    weight_liquidity: float = 0.15
    weight_ml: float = 0.30
    weight_spread: float = 0.15

    # --- Paper trading ---
    paper_trading_cycle_minutes: int = 5

    # --- Logging ---
    log_level: str = "INFO"
    log_dir: Path = Path("logs")
    log_json: bool = False

    @field_validator("max_risk_per_position_pct", "max_total_exposure_pct")
    @classmethod
    def _validate_pct(cls, v: float) -> float:
        if not 0 < v <= 1:
            raise ValueError("Les pourcentages de risque doivent être compris entre 0 et 1")
        return v

    @property
    def decision_weights_sum(self) -> float:
        return (
            self.weight_momentum
            + self.weight_volume
            + self.weight_liquidity
            + self.weight_ml
            + self.weight_spread
        )


_settings: Settings | None = None


def get_settings() -> Settings:
    """Retourne le singleton de configuration (chargé une seule fois)."""
    global _settings
    if _settings is None:
        _settings = Settings()
        _settings.cache_dir.mkdir(parents=True, exist_ok=True)
        _settings.log_dir.mkdir(parents=True, exist_ok=True)
    return _settings

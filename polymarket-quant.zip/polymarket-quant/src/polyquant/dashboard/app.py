"""Dashboard Streamlit : vue d'ensemble du système de trading simulé.

Lancement : `streamlit run src/polyquant/dashboard/app.py`
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from polyquant.backtest.engine import BacktestConfig, BacktestEngine
from polyquant.data.database import Database
from polyquant.data.replay import HistoricalReplayEngine
from polyquant.data.synthetic import generate_synthetic_universe
from polyquant.strategies import default_strategy_registry

st.set_page_config(page_title="Polyquant — Dashboard", layout="wide")

st.title("📊 Polyquant — Recherche quantitative Polymarket (simulation)")
st.caption("Système 100% simulé — aucun ordre réel n'est jamais envoyé.")


@st.cache_resource
def get_db() -> Database:
    db = Database(database_url="sqlite:///data_store/db/polyquant.db")
    db.create_schema()
    return db


db = get_db()

with st.sidebar:
    st.header("Configuration du backtest")
    initial_capital = st.number_input("Capital initial (€)", min_value=10.0, value=100.0, step=10.0)
    n_markets = st.slider("Nombre de marchés synthétiques (démo)", 5, 50, 15)
    n_points = st.slider("Nombre de cycles (points temporels)", 50, 1000, 300, step=50)
    seed = st.number_input("Seed aléatoire", min_value=0, value=7, step=1)
    use_ml = st.checkbox("Utiliser le module ML (si un modèle est entraîné)", value=False)
    run_button = st.button("▶️ Lancer un backtest", type="primary")

    st.divider()
    st.caption(
        "Cette démo génère des marchés synthétiques localement. "
        "Pour utiliser les données Polymarket réelles, exécutez "
        "`python scripts/fetch_data.py` au préalable."
    )

if run_button:
    with st.spinner("Génération des données et exécution du backtest..."):
        states = generate_synthetic_universe(
            n_markets=n_markets, n_points=n_points, seed=seed, shock_probability=0.03
        )
        db.save_snapshots(states)
        cycles = HistoricalReplayEngine(db).load()

        config = BacktestConfig(
            initial_capital=initial_capital, strategies=default_strategy_registry(), use_ml=use_ml
        )
        engine = BacktestEngine(config)
        result = engine.run(cycles)
        st.session_state["last_result"] = result

result = st.session_state.get("last_result")

if result is None:
    st.info("👈 Configurez les paramètres et cliquez sur *Lancer un backtest* pour commencer.")
else:
    perf = result.performance

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Capital actuel", f"{perf.final_equity:.2f} €", f"{perf.total_return_pct:+.2f}%")
    col2.metric("Sharpe ratio", f"{perf.sharpe_ratio:.2f}")
    col3.metric("Drawdown max", f"{perf.max_drawdown_pct:.2f}%")
    col4.metric("Taux de réussite", f"{perf.win_rate_pct:.1f}%")

    col5, col6, col7, col8 = st.columns(4)
    col5.metric("Sortino ratio", f"{perf.sortino_ratio:.2f}")
    col6.metric("Profit factor", f"{perf.profit_factor:.2f}")
    col7.metric("Expectancy", f"{perf.expectancy_eur:+.3f} €")
    col8.metric("Nombre de trades", f"{perf.n_trades}")

    st.subheader("Courbe d'équité")
    equity_df = pd.DataFrame(result.portfolio.equity_curve, columns=["timestamp", "equity"])
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=equity_df["timestamp"], y=equity_df["equity"], mode="lines", name="Équity"))
    fig.add_hline(y=initial_capital, line_dash="dash", line_color="gray", annotation_text="Capital initial")
    fig.update_layout(height=400, xaxis_title="Temps", yaxis_title="Équity (€)")
    st.plotly_chart(fig, use_container_width=True)

    col_left, col_right = st.columns(2)

    with col_left:
        st.subheader("Positions ouvertes")
        if result.portfolio.positions:
            pos_df = pd.DataFrame(
                [
                    {
                        "Marché": p.market_id,
                        "Côté": p.side.value,
                        "Quantité": round(p.quantity, 2),
                        "Prix d'entrée": round(p.entry_price, 4),
                        "Stratégie": p.strategy,
                    }
                    for p in result.portfolio.positions.values()
                ]
            )
            st.dataframe(pos_df, use_container_width=True)
        else:
            st.write("Aucune position ouverte.")

    with col_right:
        st.subheader("Statistiques des signaux")
        st.write(f"Signaux générés : **{result.n_signals_generated}**")
        st.write(f"Signaux réellement tradés : **{result.n_signals_traded}**")
        if result.n_signals_generated > 0:
            ratio = result.n_signals_traded / result.n_signals_generated * 100
            st.write(f"Taux de sélectivité : **{ratio:.1f}%** des signaux ont passé le filtre de score/risque")

    st.subheader("Historique des trades clôturés")
    if result.portfolio.closed_trades:
        trades_df = pd.DataFrame(
            [
                {
                    "Marché": t.market_id,
                    "Stratégie": t.strategy,
                    "Côté": t.side.value,
                    "Entrée": round(t.entry_price, 4),
                    "Sortie": round(t.exit_price, 4),
                    "PnL (€)": round(t.realized_pnl, 4),
                    "Raison de sortie": t.exit_reason,
                    "Ouvert le": t.entry_timestamp,
                    "Fermé le": t.exit_timestamp,
                }
                for t in result.portfolio.closed_trades
            ]
        )
        st.dataframe(trades_df.sort_values("Fermé le", ascending=False), use_container_width=True)

        st.subheader("Meilleurs marchés détectés (par PnL)")
        best_markets = (
            trades_df.groupby("Marché")["PnL (€)"].sum().sort_values(ascending=False).head(10)
        )
        st.bar_chart(best_markets)
    else:
        st.write("Aucun trade clôturé pour l'instant.")

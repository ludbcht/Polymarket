"""Cache local sur disque avec expiration (TTL), utilisé pour limiter les appels à l'API Polymarket."""

from __future__ import annotations

import hashlib
import json
from typing import Any

import diskcache

from polyquant.config import get_settings
from polyquant.logging_config import get_logger

logger = get_logger(__name__)


class LocalCache:
    """Cache clé/valeur persistant, avec TTL configurable par défaut."""

    def __init__(self, cache_dir: str | None = None, default_ttl: int | None = None) -> None:
        settings = get_settings()
        self._cache = diskcache.Cache(str(cache_dir or settings.cache_dir))
        self._default_ttl = default_ttl or settings.cache_ttl_seconds

    @staticmethod
    def make_key(*parts: Any) -> str:
        raw = json.dumps(parts, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def get(self, key: str) -> Any | None:
        value = self._cache.get(key, default=None)
        if value is not None:
            logger.debug("cache_hit", key=key[:12])
        return value

    def set(self, key: str, value: Any, ttl: int | None = None) -> None:
        self._cache.set(key, value, expire=ttl or self._default_ttl)

    def clear(self) -> None:
        self._cache.clear()

    def close(self) -> None:
        self._cache.close()


_cache: LocalCache | None = None


def get_cache() -> LocalCache:
    global _cache
    if _cache is None:
        _cache = LocalCache()
    return _cache

"""Couche d'accès à la base de données (SQLite par défaut, PostgreSQL supporté via DATABASE_URL)."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from datetime import datetime

from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session, sessionmaker

from polyquant.config import get_settings
from polyquant.data.models import Base, MarketSnapshot, MarketState, OrderAction, Side, SimulatedTrade
from polyquant.logging_config import get_logger

logger = get_logger(__name__)


class Database:
    """Wrapper autour du moteur SQLAlchemy, gère la création de schéma et les sessions."""

    def __init__(self, database_url: str | None = None) -> None:
        settings = get_settings()
        self.database_url = database_url or settings.database_url
        connect_args = {"check_same_thread": False} if "sqlite" in self.database_url else {}
        self.engine = create_engine(self.database_url, connect_args=connect_args)
        self.SessionLocal = sessionmaker(bind=self.engine, expire_on_commit=False)

    def create_schema(self) -> None:
        Base.metadata.create_all(self.engine)
        logger.info("schema_cree", database_url=self.database_url)

    @contextmanager
    def session(self) -> Iterator[Session]:
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    # --- Écriture ---

    def save_snapshot(self, state: MarketState) -> None:
        with self.session() as s:
            s.add(
                MarketSnapshot(
                    timestamp=state.timestamp,
                    market_id=state.market_id,
                    question=state.question,
                    category=state.category,
                    volume=state.volume,
                    liquidity=state.liquidity,
                    price_yes=state.price_yes,
                    price_no=state.price_no,
                    spread=state.spread,
                    order_book_depth=state.order_book_depth,
                )
            )

    def save_snapshots(self, states: list[MarketState]) -> int:
        with self.session() as s:
            s.add_all(
                [
                    MarketSnapshot(
                        timestamp=st.timestamp,
                        market_id=st.market_id,
                        question=st.question,
                        category=st.category,
                        volume=st.volume,
                        liquidity=st.liquidity,
                        price_yes=st.price_yes,
                        price_no=st.price_no,
                        spread=st.spread,
                        order_book_depth=st.order_book_depth,
                    )
                    for st in states
                ]
            )
        return len(states)

    def save_trade(
        self,
        *,
        run_id: str,
        timestamp: datetime,
        market_id: str,
        strategy: str,
        side: Side,
        action: OrderAction,
        quantity: float,
        requested_price: float,
        executed_price: float,
        fee_eur: float,
        slippage_eur: float,
        opportunity_score: float | None = None,
    ) -> None:
        with self.session() as s:
            s.add(
                SimulatedTrade(
                    run_id=run_id,
                    timestamp=timestamp,
                    market_id=market_id,
                    strategy=strategy,
                    side=side,
                    action=action,
                    quantity=quantity,
                    requested_price=requested_price,
                    executed_price=executed_price,
                    fee_eur=fee_eur,
                    slippage_eur=slippage_eur,
                    opportunity_score=opportunity_score,
                )
            )

    # --- Lecture ---

    def get_market_history(
        self, market_id: str, start: datetime | None = None, end: datetime | None = None
    ) -> list[MarketSnapshot]:
        with self.session() as s:
            stmt = select(MarketSnapshot).where(MarketSnapshot.market_id == market_id)
            if start:
                stmt = stmt.where(MarketSnapshot.timestamp >= start)
            if end:
                stmt = stmt.where(MarketSnapshot.timestamp <= end)
            stmt = stmt.order_by(MarketSnapshot.timestamp.asc())
            return list(s.execute(stmt).scalars().all())

    def get_all_market_ids(self) -> list[str]:
        with self.session() as s:
            stmt = select(MarketSnapshot.market_id).distinct()
            return [row[0] for row in s.execute(stmt).all()]

    def get_trades(self, run_id: str) -> list[SimulatedTrade]:
        with self.session() as s:
            stmt = (
                select(SimulatedTrade)
                .where(SimulatedTrade.run_id == run_id)
                .order_by(SimulatedTrade.timestamp.asc())
            )
            return list(s.execute(stmt).scalars().all())


_db: Database | None = None


def get_database() -> Database:
    global _db
    if _db is None:
        _db = Database()
        _db.create_schema()
    return _db

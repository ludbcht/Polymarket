"""Modèles de données : ORM SQLAlchemy pour la persistance + dataclasses métier légères."""

from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import datetime

from sqlalchemy import DateTime, Enum, Float, Index, Integer, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class Side(str, enum.Enum):
    YES = "YES"
    NO = "NO"


class OrderAction(str, enum.Enum):
    BUY = "BUY"
    SELL = "SELL"


class MarketSnapshot(Base):
    """Un instantané (snapshot) de l'état d'un marché Polymarket à un instant T."""

    __tablename__ = "market_snapshots"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, index=True, nullable=False)
    market_id: Mapped[str] = mapped_column(String(128), index=True, nullable=False)
    question: Mapped[str] = mapped_column(String(512), nullable=False)
    category: Mapped[str] = mapped_column(String(128), nullable=True)
    volume: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    liquidity: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    price_yes: Mapped[float] = mapped_column(Float, nullable=False)
    price_no: Mapped[float] = mapped_column(Float, nullable=False)
    spread: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    order_book_depth: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)

    __table_args__ = (
        Index("ix_market_ts", "market_id", "timestamp"),
    )


class SimulatedTrade(Base):
    """Un trade exécuté en simulation (backtest ou paper trading)."""

    __tablename__ = "simulated_trades"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime, index=True, nullable=False)
    market_id: Mapped[str] = mapped_column(String(128), index=True, nullable=False)
    strategy: Mapped[str] = mapped_column(String(64), nullable=False)
    side: Mapped[Side] = mapped_column(Enum(Side), nullable=False)
    action: Mapped[OrderAction] = mapped_column(Enum(OrderAction), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    requested_price: Mapped[float] = mapped_column(Float, nullable=False)
    executed_price: Mapped[float] = mapped_column(Float, nullable=False)
    fee_eur: Mapped[float] = mapped_column(Float, nullable=False)
    slippage_eur: Mapped[float] = mapped_column(Float, nullable=False)
    opportunity_score: Mapped[float] = mapped_column(Float, nullable=True)


@dataclass(frozen=True, slots=True)
class MarketState:
    """Représentation métier immuable d'un marché à un instant donné (utilisée en mémoire)."""

    market_id: str
    question: str
    category: str
    timestamp: datetime
    volume: float
    liquidity: float
    price_yes: float
    price_no: float
    spread: float
    order_book_depth: float

    @property
    def mid_price(self) -> float:
        return (self.price_yes + (1 - self.price_no)) / 2

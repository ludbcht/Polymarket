"""Client pour les API publiques de Polymarket.

Deux API publiques sont utilisées :
- Gamma API (https://gamma-api.polymarket.com) : métadonnées des marchés, catégories,
  volumes, liquidité, statut actif/résolu.
- CLOB API (https://clob.polymarket.com) : carnets d'ordres, prix, spreads, profondeur.

Toutes les requêtes sont mises en cache localement (TTL configurable) et protégées par
un mécanisme de retry avec backoff exponentiel (tenacity), car ce sont des API publiques
sujettes à rate limiting.

Ce client est en lecture seule : aucune méthode de passage d'ordre n'est implémentée,
conformément à l'exigence de fonctionnement 100% simulé du système.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from polyquant.config import get_settings
from polyquant.data.cache import get_cache
from polyquant.data.models import MarketState
from polyquant.logging_config import get_logger

logger = get_logger(__name__)


class PolymarketAPIError(RuntimeError):
    """Erreur levée lors d'un échec de communication avec l'API Polymarket."""


class PolymarketClient:
    """Client HTTP en lecture seule pour les API publiques Polymarket."""

    def __init__(self) -> None:
        settings = get_settings()
        self._settings = settings
        self._cache = get_cache()
        self._gamma = httpx.Client(
            base_url=settings.polymarket_gamma_api_url,
            timeout=settings.polymarket_api_timeout_seconds,
            headers={"Accept": "application/json"},
        )
        self._clob = httpx.Client(
            base_url=settings.polymarket_clob_api_url,
            timeout=settings.polymarket_api_timeout_seconds,
            headers={"Accept": "application/json"},
        )

    def close(self) -> None:
        self._gamma.close()
        self._clob.close()

    def __enter__(self) -> PolymarketClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # --- Requêtes bas niveau avec retry + cache ---

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=0.5, min=0.5, max=8),
        retry=retry_if_exception_type((httpx.TransportError, httpx.HTTPStatusError)),
        reraise=True,
    )
    def _get(self, client: httpx.Client, path: str, params: dict[str, Any] | None = None) -> Any:
        cache_key = self._cache.make_key("http_get", str(client.base_url), path, params)
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached
        try:
            response = client.get(path, params=params)
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.warning("api_http_error", path=path, status=exc.response.status_code)
            raise
        except httpx.TransportError as exc:
            logger.warning("api_transport_error", path=path, error=str(exc))
            raise

        data = response.json()
        self._cache.set(cache_key, data)
        return data

    # --- Marchés (Gamma API) ---

    def get_active_markets(self, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
        """Récupère les marchés actuellement actifs."""
        try:
            data = self._get(
                self._gamma,
                "/markets",
                params={"active": "true", "closed": "false", "limit": limit, "offset": offset},
            )
        except (httpx.HTTPStatusError, httpx.TransportError) as exc:
            raise PolymarketAPIError(f"Impossible de récupérer les marchés actifs: {exc}") from exc
        return data if isinstance(data, list) else data.get("data", [])

    def get_market_by_id(self, market_id: str) -> dict[str, Any] | None:
        try:
            data = self._get(self._gamma, f"/markets/{market_id}")
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code == 404:
                return None
            raise PolymarketAPIError(f"Erreur lors de la récupération du marché {market_id}: {exc}") from exc
        except httpx.TransportError as exc:
            raise PolymarketAPIError(f"Erreur réseau pour le marché {market_id}: {exc}") from exc
        return data

    def get_historical_markets(
        self, limit: int = 100, offset: int = 0
    ) -> list[dict[str, Any]]:
        """Récupère des marchés résolus/historiques (pour constitution de jeux de backtest)."""
        try:
            data = self._get(
                self._gamma,
                "/markets",
                params={"closed": "true", "limit": limit, "offset": offset},
            )
        except (httpx.HTTPStatusError, httpx.TransportError) as exc:
            raise PolymarketAPIError(f"Impossible de récupérer les marchés historiques: {exc}") from exc
        return data if isinstance(data, list) else data.get("data", [])

    # --- Carnet d'ordres (CLOB API) ---

    def get_order_book(self, token_id: str) -> dict[str, Any]:
        try:
            return self._get(self._clob, "/book", params={"token_id": token_id})
        except (httpx.HTTPStatusError, httpx.TransportError) as exc:
            raise PolymarketAPIError(f"Impossible de récupérer le carnet d'ordres {token_id}: {exc}") from exc

    def get_price(self, token_id: str, side: str = "BUY") -> float | None:
        try:
            data = self._get(self._clob, "/price", params={"token_id": token_id, "side": side})
        except (httpx.HTTPStatusError, httpx.TransportError) as exc:
            raise PolymarketAPIError(f"Impossible de récupérer le prix {token_id}: {exc}") from exc
        price = data.get("price") if isinstance(data, dict) else None
        return float(price) if price is not None else None

    # --- Conversion vers le modèle métier interne ---

    @staticmethod
    def parse_market_state(raw: dict[str, Any]) -> MarketState | None:
        """Convertit une réponse brute Gamma API en `MarketState` interne.

        Retourne None si les champs essentiels sont absents (marché mal formé/incomplet).
        """
        try:
            market_id = str(raw["id"])
            question = raw.get("question", "")
            category = raw.get("category") or raw.get("groupItemTitle") or "unknown"

            outcome_prices = raw.get("outcomePrices")
            if isinstance(outcome_prices, str):
                import json as _json

                outcome_prices = _json.loads(outcome_prices)
            price_yes = float(outcome_prices[0]) if outcome_prices else float(raw.get("lastTradePrice", 0.5))
            price_no = 1.0 - price_yes if outcome_prices else float(1 - price_yes)

            volume = float(raw.get("volume", 0.0) or 0.0)
            liquidity = float(raw.get("liquidity", 0.0) or 0.0)
            spread = float(raw.get("spread", 0.0) or 0.0)
            depth = float(raw.get("orderBookDepth", liquidity) or 0.0)

            return MarketState(
                market_id=market_id,
                question=question,
                category=category,
                timestamp=datetime.now(UTC),
                volume=volume,
                liquidity=liquidity,
                price_yes=price_yes,
                price_no=price_no,
                spread=spread,
                order_book_depth=depth,
            )
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            logger.debug("market_parse_echec", error=str(exc), raw_id=raw.get("id"))
            return None

    def fetch_market_states(self, limit: int = 100) -> list[MarketState]:
        """Récupère les marchés actifs et les convertit en `MarketState` exploitables."""
        raw_markets = self.get_active_markets(limit=limit)
        states = [self.parse_market_state(m) for m in raw_markets]
        return [s for s in states if s is not None]

"""Moteur de replay historique.

Rejoue chronologiquement les snapshots de marché stockés en base, cycle par cycle,
pour alimenter le moteur de backtest de façon déterministe et reproductible.
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from datetime import datetime

from polyquant.data.database import Database
from polyquant.data.models import MarketState
from polyquant.logging_config import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class ReplayCycle:
    """Un instant de replay : l'ensemble des états de marché disponibles à ce timestamp."""

    timestamp: datetime
    markets: dict[str, MarketState]


class HistoricalReplayEngine:
    """Reconstruit une séquence chronologique de cycles de marché à partir de la base."""

    def __init__(self, db: Database, market_ids: list[str] | None = None) -> None:
        self._db = db
        self._market_ids = market_ids

    def load(self, start: datetime | None = None, end: datetime | None = None) -> list[ReplayCycle]:
        market_ids = self._market_ids or self._db.get_all_market_ids()
        if not market_ids:
            logger.warning("replay_aucune_donnee")
            return []

        by_timestamp: dict[datetime, dict[str, MarketState]] = {}
        for market_id in market_ids:
            snapshots = self._db.get_market_history(market_id, start=start, end=end)
            for snap in snapshots:
                state = MarketState(
                    market_id=snap.market_id,
                    question=snap.question,
                    category=snap.category or "unknown",
                    timestamp=snap.timestamp,
                    volume=snap.volume,
                    liquidity=snap.liquidity,
                    price_yes=snap.price_yes,
                    price_no=snap.price_no,
                    spread=snap.spread,
                    order_book_depth=snap.order_book_depth,
                )
                by_timestamp.setdefault(snap.timestamp, {})[market_id] = state

        cycles = [
            ReplayCycle(timestamp=ts, markets=markets)
            for ts, markets in sorted(by_timestamp.items(), key=lambda kv: kv[0])
        ]
        logger.info("replay_charge", nb_cycles=len(cycles), nb_marches=len(market_ids))
        return cycles

    def iter_cycles(
        self, start: datetime | None = None, end: datetime | None = None
    ) -> Iterator[ReplayCycle]:
        yield from self.load(start=start, end=end)

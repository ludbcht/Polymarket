"""Générateur de données de marché synthétiques mais réalistes.

Utilisé pour :
- les tests unitaires (déterministes, sans appel réseau) ;
- la démonstration / le premier backtest de bout en bout sans clé API ni accès réseau ;
- la génération de jeux d'entraînement ML additionnels.

Le modèle sous-jacent est une marche aléatoire bornée sur la probabilité (prix YES dans
[0.01, 0.99]), avec volatilité, volume et liquidité corrélés à des régimes de marché
(calme / actif / choc), afin que les stratégies aient un signal exploitable à détecter.
"""

from __future__ import annotations

import random
from datetime import UTC, datetime, timedelta

from polyquant.data.models import MarketState


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def generate_synthetic_market_history(
    market_id: str,
    question: str,
    category: str,
    *,
    n_points: int = 500,
    interval_minutes: int = 5,
    start: datetime | None = None,
    initial_price: float | None = None,
    seed: int | None = None,
    shock_probability: float = 0.02,
) -> list[MarketState]:
    """Génère une série temporelle synthétique de `MarketState` pour un marché donné."""
    rng = random.Random(seed)
    start = start or (datetime.now(UTC) - timedelta(minutes=interval_minutes * n_points))
    price = initial_price if initial_price is not None else rng.uniform(0.1, 0.9)
    base_volume = rng.uniform(5_000, 200_000)
    base_liquidity = rng.uniform(2_000, 100_000)

    states: list[MarketState] = []
    volatility_regime = 0.01

    for i in range(n_points):
        ts = start + timedelta(minutes=interval_minutes * i)

        # Régime de volatilité : chocs occasionnels puis retour au calme
        if rng.random() < shock_probability:
            volatility_regime = rng.uniform(0.05, 0.15)
        else:
            volatility_regime = max(0.005, volatility_regime * 0.9)

        drift = rng.gauss(0, volatility_regime)
        price = _clip(price + drift, 0.01, 0.99)

        volume_noise = rng.uniform(0.7, 1.4) * (1 + volatility_regime * 5)
        volume = max(0.0, base_volume * volume_noise * (i + 1) / n_points)
        liquidity = max(1.0, base_liquidity * rng.uniform(0.8, 1.2) / (1 + volatility_regime * 3))
        spread = _clip(0.01 + volatility_regime * 0.5 + rng.uniform(0, 0.01), 0.001, 0.2)
        depth = liquidity * rng.uniform(0.3, 0.9)

        states.append(
            MarketState(
                market_id=market_id,
                question=question,
                category=category,
                timestamp=ts,
                volume=round(volume, 2),
                liquidity=round(liquidity, 2),
                price_yes=round(price, 4),
                price_no=round(1 - price, 4),
                spread=round(spread, 4),
                order_book_depth=round(depth, 2),
            )
        )

    return states


def generate_synthetic_universe(
    n_markets: int = 20,
    seed: int = 42,
    *,
    n_points: int = 500,
    interval_minutes: int = 5,
    start: datetime | None = None,
    **kwargs: object,
) -> list[MarketState]:
    """Génère un univers de plusieurs marchés synthétiques concaténés (pour peuplement de la base).

    Tous les marchés partagent le même horodatage de départ et le même pas de temps,
    afin que le moteur de replay puisse les regrouper correctement par cycle.
    """
    rng = random.Random(seed)
    shared_start = start or (datetime.now(UTC) - timedelta(minutes=interval_minutes * n_points))
    categories = ["Politique", "Sport", "Crypto", "Économie", "Divertissement", "Science"]
    all_states: list[MarketState] = []
    for i in range(n_markets):
        market_id = f"synthetic-{i:04d}"
        category = rng.choice(categories)
        question = f"[{category}] Événement synthétique n°{i} se réalisera-t-il ?"
        all_states.extend(
            generate_synthetic_market_history(
                market_id,
                question,
                category,
                n_points=n_points,
                interval_minutes=interval_minutes,
                start=shared_start,
                seed=seed + i,
                **kwargs,  # type: ignore[arg-type]
            )
        )
    return all_states

"""Moteur de décision : calcule un score d'opportunité composite et décide s'il faut trader.

Aucune position n'est jamais ouverte sans qu'un signal existe ET que le score dépasse
le seuil configuré. C'est le garde-fou central contre le sur-trading.
"""

from __future__ import annotations

from dataclasses import dataclass

from polyquant.config import get_settings
from polyquant.data.models import MarketState, Side
from polyquant.strategies.base import StrategySignal


@dataclass(frozen=True, slots=True)
class OpportunityScore:
    market_id: str
    side: Side
    score: float
    momentum_component: float
    volume_component: float
    liquidity_component: float
    ml_component: float
    spread_component: float
    contributing_strategies: tuple[str, ...]
    tradable: bool


class DecisionScorer:
    """Combine les signaux de stratégies, l'état de marché et une éventuelle prédiction ML
    en un score d'opportunité unique, comparé à un seuil configurable pour décider d'agir.
    """

    def __init__(
        self,
        weight_momentum: float | None = None,
        weight_volume: float | None = None,
        weight_liquidity: float | None = None,
        weight_ml: float | None = None,
        weight_spread: float | None = None,
        threshold: float | None = None,
    ) -> None:
        settings = get_settings()
        self.weight_momentum = weight_momentum if weight_momentum is not None else settings.weight_momentum
        self.weight_volume = weight_volume if weight_volume is not None else settings.weight_volume
        self.weight_liquidity = (
            weight_liquidity if weight_liquidity is not None else settings.weight_liquidity
        )
        self.weight_ml = weight_ml if weight_ml is not None else settings.weight_ml
        self.weight_spread = weight_spread if weight_spread is not None else settings.weight_spread
        self.threshold = threshold if threshold is not None else settings.opportunity_score_threshold

    @staticmethod
    def _aggregate_signals(signals: list[StrategySignal]) -> tuple[Side, float, tuple[str, ...]] | None:
        """Agrège plusieurs signaux (potentiellement contradictoires) sur un même marché.

        Ne retient que la direction majoritaire pondérée par la force des signaux ; si les
        signaux s'annulent (conflit fort), aucune direction claire n'émerge -> pas de trade.
        """
        if not signals:
            return None
        yes_strength = sum(s.strength for s in signals if s.side == Side.YES)
        no_strength = sum(s.strength for s in signals if s.side == Side.NO)

        if yes_strength == 0 and no_strength == 0:
            return None
        if abs(yes_strength - no_strength) < 0.15 * max(yes_strength, no_strength, 1e-9):
            # Conflit trop important entre stratégies : pas de conviction nette.
            return None

        side = Side.YES if yes_strength > no_strength else Side.NO
        agg_strength = max(yes_strength, no_strength) / len(signals)
        contributing = tuple(s.strategy_name for s in signals if s.side == side)
        return side, min(agg_strength, 1.0), contributing

    def score(
        self,
        market: MarketState,
        signals: list[StrategySignal],
        ml_probability: float | None = None,
    ) -> OpportunityScore | None:
        """Calcule le score d'opportunité pour un marché. Retourne None si aucun signal."""
        aggregated = self._aggregate_signals(signals)
        if aggregated is None:
            return None
        side, momentum_component, contributing = aggregated

        volume_component = min(market.volume / 100_000, 1.0)
        liquidity_component = min(market.liquidity / 50_000, 1.0)
        spread_component = max(0.0, 1.0 - min(market.spread / 0.1, 1.0))
        ml_component = ml_probability if ml_probability is not None else 0.5

        score = (
            self.weight_momentum * momentum_component
            + self.weight_volume * volume_component
            + self.weight_liquidity * liquidity_component
            + self.weight_ml * ml_component
            + self.weight_spread * spread_component
        )

        return OpportunityScore(
            market_id=market.market_id,
            side=side,
            score=score,
            momentum_component=momentum_component,
            volume_component=volume_component,
            liquidity_component=liquidity_component,
            ml_component=ml_component,
            spread_component=spread_component,
            contributing_strategies=contributing,
            tradable=score >= self.threshold,
        )

"""Logging avancé : sortie console lisible + fichier rotatif + format JSON optionnel.

Utilise `structlog` par-dessus le module `logging` standard pour obtenir des logs
structurés, facilement exploitables (monitoring, debug, audit des décisions de trading).
"""

from __future__ import annotations

import logging
import logging.handlers
import sys

import structlog

from polyquant.config import get_settings

_configured = False


def configure_logging() -> None:
    """Configure le logging global de l'application (idempotent)."""
    global _configured
    if _configured:
        return

    settings = get_settings()
    level = getattr(logging, settings.log_level.upper(), logging.INFO)

    settings.log_dir.mkdir(parents=True, exist_ok=True)
    log_file = settings.log_dir / "polyquant.log"

    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    console_handler = logging.StreamHandler(sys.stdout)

    logging.basicConfig(
        level=level,
        format="%(message)s",
        handlers=[console_handler, file_handler],
    )

    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]

    renderer: structlog.types.Processor
    if settings.log_json:
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    structlog.configure(
        processors=[*shared_processors, structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[structlog.stdlib.ProcessorFormatter.remove_processors_meta, renderer],
        foreign_pre_chain=shared_processors,
    )
    for handler in (console_handler, file_handler):
        handler.setFormatter(formatter)

    _configured = True


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Retourne un logger structuré nommé, après s'être assuré de la configuration."""
    configure_logging()
    return structlog.get_logger(name)

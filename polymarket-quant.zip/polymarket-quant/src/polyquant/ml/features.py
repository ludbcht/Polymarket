"""Extraction de features à partir de l'historique d'un marché, pour le pipeline ML."""

from __future__ import annotations

from dataclasses import dataclass

from polyquant.strategies.base import MarketHistory

FEATURE_NAMES = [
    "price_change_5m",
    "price_change_15m",
    "price_change_1h",
    "price_change_24h",
    "volume",
    "volume_zscore",
    "liquidity",
    "spread",
    "order_book_depth",
    "realized_volatility",
    "current_price",
]


@dataclass(frozen=True, slots=True)
class FeatureVector:
    market_id: str
    values: dict[str, float]

    def as_ordered_list(self) -> list[float]:
        return [self.values.get(name, 0.0) for name in FEATURE_NAMES]


def extract_features(
    history: MarketHistory,
    *,
    points_per_5min: int = 1,
) -> FeatureVector | None:
    """Extrait un vecteur de features à partir de l'historique récent d'un marché.

    `points_per_5min` permet d'adapter les fenêtres de lookback (5min/15min/1h/24h) à la
    granularité réelle des données (par défaut, un point = un cycle de 5 minutes).
    """
    latest = history.latest
    if latest is None:
        return None

    lookback_5m = points_per_5min
    lookback_15m = points_per_5min * 3
    lookback_1h = points_per_5min * 12
    lookback_24h = points_per_5min * 288

    values = {
        "price_change_5m": history.price_change(lookback_5m) or 0.0,
        "price_change_15m": history.price_change(lookback_15m) or 0.0,
        "price_change_1h": history.price_change(lookback_1h) or 0.0,
        "price_change_24h": history.price_change(lookback_24h) or 0.0,
        "volume": latest.volume,
        "volume_zscore": history.volume_zscore(20) or 0.0,
        "liquidity": latest.liquidity,
        "spread": latest.spread,
        "order_book_depth": latest.order_book_depth,
        "realized_volatility": history.realized_volatility(20) or 0.0,
        "current_price": latest.price_yes,
    }
    return FeatureVector(market_id=history.market_id, values=values)


def build_training_dataset(
    histories: list[MarketHistory], horizon: int = 6, favorable_threshold: float = 0.01
) -> tuple[list[list[float]], list[int]]:
    """Construit un jeu d'entraînement supervisé à partir d'historiques complets.

    Label = 1 si le prix évolue favorablement (hausse) de plus de `favorable_threshold`
    dans les `horizon` cycles suivants, 0 sinon. Utilisé pour prédire un mouvement haussier
    à 30 minutes (horizon=6 cycles de 5 minutes par défaut).
    """
    X: list[list[float]] = []
    y: list[int] = []

    for history in histories:
        states = history.states
        for i in range(20, len(states) - horizon):
            window = MarketHistory(market_id=history.market_id, states=states[: i + 1])
            features = extract_features(window)
            if features is None:
                continue
            future_price = states[i + horizon].price_yes
            current_price = states[i].price_yes
            label = 1 if (future_price - current_price) > favorable_threshold else 0
            X.append(features.as_ordered_list())
            y.append(label)

    return X, y

"""Wrappers uniformisés autour des modèles ML candidats : XGBoost, LightGBM, Random Forest.

Objectif : prédire la probabilité qu'un marché évolue favorablement (hausse du prix YES)
dans les 30 prochaines minutes, à partir des features extraites de l'historique récent.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split


class ClassifierProtocol(Protocol):
    def fit(self, X: Any, y: Any) -> Any: ...
    def predict_proba(self, X: Any) -> Any: ...


@dataclass(slots=True)
class ModelEvaluation:
    model_name: str
    accuracy: float
    f1: float
    roc_auc: float
    n_train: int
    n_test: int


def _build_random_forest() -> ClassifierProtocol:
    return RandomForestClassifier(n_estimators=200, max_depth=8, min_samples_leaf=5, random_state=42)


def _build_xgboost() -> ClassifierProtocol:
    import xgboost as xgb

    return xgb.XGBClassifier(
        n_estimators=200,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        eval_metric="logloss",
        random_state=42,
    )


def _build_lightgbm() -> ClassifierProtocol:
    import lightgbm as lgb

    return lgb.LGBMClassifier(
        n_estimators=200,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        verbosity=-1,
    )


MODEL_BUILDERS: dict[str, Any] = {
    "random_forest": _build_random_forest,
    "xgboost": _build_xgboost,
    "lightgbm": _build_lightgbm,
}


def train_and_evaluate(
    model_name: str, X: list[list[float]], y: list[int], test_size: float = 0.25
) -> tuple[ClassifierProtocol, ModelEvaluation]:
    """Entraîne un modèle et retourne le modèle entraîné + ses métriques sur un jeu de test."""
    if model_name not in MODEL_BUILDERS:
        raise ValueError(f"Modèle inconnu: {model_name}. Options: {list(MODEL_BUILDERS)}")

    X_arr = np.array(X)
    y_arr = np.array(y)

    if len(set(y_arr.tolist())) < 2:
        raise ValueError("Le jeu d'entraînement ne contient qu'une seule classe: impossible d'entraîner")

    X_train, X_test, y_train, y_test = train_test_split(
        X_arr, y_arr, test_size=test_size, random_state=42, stratify=y_arr
    )

    model = MODEL_BUILDERS[model_name]()
    model.fit(X_train, y_train)

    proba = model.predict_proba(X_test)[:, 1]
    preds = (proba >= 0.5).astype(int)

    evaluation = ModelEvaluation(
        model_name=model_name,
        accuracy=accuracy_score(y_test, preds),
        f1=f1_score(y_test, preds, zero_division=0),
        roc_auc=roc_auc_score(y_test, proba) if len(set(y_test.tolist())) > 1 else 0.5,
        n_train=len(X_train),
        n_test=len(X_test),
    )
    return model, evaluation


def compare_models(X: list[list[float]], y: list[int]) -> dict[str, ModelEvaluation]:
    """Entraîne et compare tous les modèles disponibles sur le même jeu de données."""
    results: dict[str, ModelEvaluation] = {}
    for name in MODEL_BUILDERS:
        try:
            _, evaluation = train_and_evaluate(name, X, y)
            results[name] = evaluation
        except (ValueError, ImportError) as exc:
            from polyquant.logging_config import get_logger

            get_logger(__name__).warning("modele_non_evaluable", model=name, error=str(exc))
    return results

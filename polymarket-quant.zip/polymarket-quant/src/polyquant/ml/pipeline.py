"""Pipeline ML de bout en bout : construction du jeu de données, entraînement, comparaison
des modèles, et prédiction en ligne utilisée par le moteur de décision.
"""

from __future__ import annotations

from dataclasses import dataclass

from polyquant.data.database import Database
from polyquant.data.replay import HistoricalReplayEngine
from polyquant.logging_config import get_logger
from polyquant.ml.features import build_training_dataset, extract_features
from polyquant.ml.models import ClassifierProtocol, ModelEvaluation, compare_models, train_and_evaluate
from polyquant.strategies.base import MarketHistory

logger = get_logger(__name__)


@dataclass(slots=True)
class TrainingReport:
    best_model_name: str
    evaluations: dict[str, ModelEvaluation]
    n_samples: int


class MLPredictor:
    """Enveloppe un modèle entraîné et l'expose au moteur de décision via `predict_proba`."""

    def __init__(self, model: ClassifierProtocol | None = None, model_name: str = "aucun") -> None:
        self.model = model
        self.model_name = model_name

    def predict_proba(self, history: MarketHistory) -> float | None:
        """Retourne la probabilité prédite d'évolution favorable, ou None si le modèle
        n'est pas entraîné ou si les features ne peuvent pas être extraites.
        """
        if self.model is None:
            return None
        features = extract_features(history)
        if features is None:
            return None
        try:
            proba = self.model.predict_proba([features.as_ordered_list()])
            return float(proba[0][1])
        except Exception:  # noqa: BLE001
            logger.exception("erreur_prediction_ml", market_id=history.market_id)
            return None

    @classmethod
    def train_from_database(
        cls, db: Database, horizon: int = 6, favorable_threshold: float = 0.01
    ) -> tuple[MLPredictor, TrainingReport]:
        """Entraîne le meilleur modèle disponible à partir de l'historique stocké en base."""
        replay = HistoricalReplayEngine(db)
        cycles = replay.load()

        histories: dict[str, list] = {}
        for cycle in cycles:
            for market_id, state in cycle.markets.items():
                histories.setdefault(market_id, []).append(state)

        market_histories = [MarketHistory(market_id=mid, states=states) for mid, states in histories.items()]

        X, y = build_training_dataset(market_histories, horizon=horizon, favorable_threshold=favorable_threshold)
        logger.info("dataset_ml_construit", n_echantillons=len(X), n_marches=len(market_histories))

        if len(X) < 50:
            logger.warning("dataset_ml_insuffisant", n_echantillons=len(X))
            return cls(model=None), TrainingReport(best_model_name="aucun", evaluations={}, n_samples=len(X))

        evaluations = compare_models(X, y)
        if not evaluations:
            return cls(model=None), TrainingReport(best_model_name="aucun", evaluations={}, n_samples=len(X))

        best_name = max(evaluations, key=lambda name: evaluations[name].roc_auc)
        best_model, _ = train_and_evaluate(best_name, X, y)

        logger.info(
            "meilleur_modele_selectionne",
            modele=best_name,
            roc_auc=round(evaluations[best_name].roc_auc, 4),
        )

        predictor = cls(model=best_model, model_name=best_name)
        report = TrainingReport(best_model_name=best_name, evaluations=evaluations, n_samples=len(X))
        return predictor, report

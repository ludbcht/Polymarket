"""Moteur d'optimisation automatique des paramètres de trading via Optuna.

Cherche les paramètres (seuil de décision, taille de risque par position, poids du
scorer) qui maximisent le Sharpe ratio sur un jeu de cycles de replay donné.
"""

from __future__ import annotations

from dataclasses import dataclass

import optuna

from polyquant.backtest.engine import BacktestConfig, BacktestEngine
from polyquant.data.replay import ReplayCycle
from polyquant.decision.scorer import DecisionScorer
from polyquant.logging_config import get_logger
from polyquant.risk.manager import RiskManager
from polyquant.strategies import default_strategy_registry

logger = get_logger(__name__)

optuna.logging.set_verbosity(optuna.logging.WARNING)


@dataclass(frozen=True, slots=True)
class OptimizationResult:
    best_params: dict[str, float]
    best_sharpe: float
    n_trials: int
    study: optuna.Study


def _objective_factory(cycles: list[ReplayCycle], initial_capital: float):
    def objective(trial: optuna.Trial) -> float:
        threshold = trial.suggest_float("opportunity_score_threshold", 0.4, 0.9)
        risk_per_position = trial.suggest_float("max_risk_per_position_pct", 0.005, 0.03)
        stop_loss = trial.suggest_float("stop_loss_pct", 0.05, 0.25)
        take_profit = trial.suggest_float("take_profit_pct", 0.10, 0.50)
        weight_ml = trial.suggest_float("weight_ml", 0.0, 0.5)
        weight_momentum = trial.suggest_float("weight_momentum", 0.0, 0.5)

        remaining = max(1e-6, 1.0 - weight_ml - weight_momentum)
        weight_volume = remaining / 3
        weight_liquidity = remaining / 3
        weight_spread = remaining / 3

        scorer = DecisionScorer(
            weight_momentum=weight_momentum,
            weight_volume=weight_volume,
            weight_liquidity=weight_liquidity,
            weight_ml=weight_ml,
            weight_spread=weight_spread,
            threshold=threshold,
        )
        risk_manager = RiskManager(
            max_risk_per_position_pct=risk_per_position,
            stop_loss_pct=stop_loss,
            take_profit_pct=take_profit,
        )

        config = BacktestConfig(
            initial_capital=initial_capital, strategies=default_strategy_registry(), use_ml=False
        )
        engine = BacktestEngine(config, scorer=scorer, risk_manager=risk_manager)
        result = engine.run(cycles)

        # Pénalise fortement l'absence totale de trades (paramètres trop restrictifs)
        # pour éviter que l'optimiseur converge vers "ne jamais trader".
        if result.performance.n_trades == 0:
            return -10.0

        return result.performance.sharpe_ratio

    return objective


def optimize_parameters(
    cycles: list[ReplayCycle], initial_capital: float = 100.0, n_trials: int = 50
) -> OptimizationResult:
    """Lance une recherche Optuna pour maximiser le Sharpe ratio sur les cycles fournis."""
    study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=42))
    objective = _objective_factory(cycles, initial_capital)
    study.optimize(objective, n_trials=n_trials, show_progress_bar=False)

    logger.info(
        "optimisation_terminee",
        n_trials=n_trials,
        meilleur_sharpe=round(study.best_value, 4),
        meilleurs_params=study.best_params,
    )

    return OptimizationResult(
        best_params=study.best_params,
        best_sharpe=study.best_value,
        n_trials=n_trials,
        study=study,
    )

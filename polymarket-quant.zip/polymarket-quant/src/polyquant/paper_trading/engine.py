"""Moteur de Paper Trading.

Analyse le marché à intervalle régulier (5 minutes par défaut) mais n'ouvre une position
que si un avantage statistique mesurable est détecté (signal + score au-dessus du seuil).
Aucun ordre réel n'est jamais envoyé : `PolymarketClient` est strictement en lecture seule.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime

from polyquant.backtest.execution import ExecutionSimulator
from polyquant.backtest.portfolio import Portfolio
from polyquant.config import get_settings
from polyquant.data.database import Database
from polyquant.data.models import OrderAction, Side
from polyquant.data.polymarket_client import PolymarketClient
from polyquant.decision.scorer import DecisionScorer
from polyquant.logging_config import get_logger
from polyquant.ml.pipeline import MLPredictor
from polyquant.risk.manager import RiskManager
from polyquant.strategies import default_strategy_registry
from polyquant.strategies.base import MarketHistory, Strategy

logger = get_logger(__name__)


@dataclass(slots=True)
class PaperTradingConfig:
    initial_capital: float = 100.0
    history_window: int = 60
    strategies: list[Strategy] = field(default_factory=default_strategy_registry)
    cycle_minutes: int | None = None
    max_markets_per_cycle: int = 100


class PaperTradingEngine:
    """Boucle de paper trading : à chaque cycle, met à jour l'état, cherche des opportunités,
    et ne trade que si un avantage statistique suffisant est détecté sur au moins un marché.
    """

    def __init__(
        self,
        config: PaperTradingConfig | None = None,
        client: PolymarketClient | None = None,
        db: Database | None = None,
        scorer: DecisionScorer | None = None,
        risk_manager: RiskManager | None = None,
        ml_predictor: MLPredictor | None = None,
    ) -> None:
        settings = get_settings()
        self.config = config or PaperTradingConfig(initial_capital=settings.initial_capital_eur)
        self.client = client or PolymarketClient()
        self.db = db
        self.scorer = scorer or DecisionScorer()
        self.risk_manager = risk_manager or RiskManager()
        self.execution = ExecutionSimulator()
        self.ml_predictor = ml_predictor
        self.cycle_minutes = self.config.cycle_minutes or settings.paper_trading_cycle_minutes

        self.portfolio = Portfolio(initial_capital=self.config.initial_capital)
        self.run_id = f"paper-{uuid.uuid4().hex[:8]}"
        self._histories: dict[str, MarketHistory] = {}

    def _mark_to_market_prices(self, latest_states: dict[str, object]) -> dict[str, float]:
        prices: dict[str, float] = {}
        for market_id, position in self.portfolio.positions.items():
            state = latest_states.get(market_id)
            if state is None:
                continue
            prices[market_id] = state.price_yes if position.side == Side.YES else state.price_no  # type: ignore[attr-defined]
        return prices

    def run_cycle(self) -> dict[str, object]:
        """Exécute un unique cycle d'analyse. Retourne un résumé de ce qui s'est passé."""
        try:
            states = self.client.fetch_market_states(limit=self.config.max_markets_per_cycle)
        except Exception:  # noqa: BLE001 - un échec réseau ne doit jamais planter la boucle
            logger.exception("echec_recuperation_marches")
            return {"status": "erreur_reseau", "positions_ouvertes": 0, "positions_fermees": 0}

        latest_by_id = {s.market_id: s for s in states}
        for market_id, state in latest_by_id.items():
            history = self._histories.get(market_id, MarketHistory(market_id=market_id, states=[]))
            new_states = [*history.states, state][-self.config.history_window :]
            self._histories[market_id] = MarketHistory(market_id=market_id, states=new_states)

        n_opened = 0
        n_closed = 0

        # --- Gestion des sorties (stop-loss / take-profit) ---
        for market_id in list(self.portfolio.positions.keys()):
            state = latest_by_id.get(market_id)
            if state is None:
                continue
            position = self.portfolio.positions[market_id]
            current_price = state.price_yes if position.side == Side.YES else state.price_no
            reason = self.risk_manager.should_exit_on_stops(
                current_price, position.stop_loss_price, position.take_profit_price
            )
            if reason is None:
                continue
            result = self.execution.simulate_market_order(
                state, position.side, OrderAction.SELL, position.quantity * current_price
            )
            if result.rejected:
                continue
            self.portfolio.close_position(market_id, result.executed_price, result.fee_eur, state.timestamp, reason)
            n_closed += 1
            if self.db:
                self.db.save_trade(
                    run_id=self.run_id,
                    timestamp=state.timestamp,
                    market_id=market_id,
                    strategy=position.strategy,
                    side=position.side,
                    action=OrderAction.SELL,
                    quantity=result.quantity,
                    requested_price=result.requested_price,
                    executed_price=result.executed_price,
                    fee_eur=result.fee_eur,
                    slippage_eur=result.slippage_eur,
                )

        self.portfolio.record_equity(datetime.now(UTC), self._mark_to_market_prices(latest_by_id))

        # --- Recherche d'opportunités : aucune position n'est ouverte sans signal ET score suffisant ---
        best_opportunity_this_cycle = None
        for market_id, state in latest_by_id.items():
            if market_id in self.portfolio.positions:
                continue
            history = self._histories.get(market_id)
            if history is None:
                continue

            signals = []
            for strategy in self.config.strategies:
                try:
                    signal = strategy.generate_signal(history)
                except Exception:  # noqa: BLE001
                    logger.exception("erreur_strategie_paper", strategy=strategy.name)
                    continue
                if signal is not None:
                    signals.append(signal)
            if not signals:
                continue

            ml_probability = self.ml_predictor.predict_proba(history) if self.ml_predictor else None
            opportunity = self.scorer.score(state, signals, ml_probability)
            if opportunity is None or not opportunity.tradable:
                continue

            if best_opportunity_this_cycle is None or opportunity.score > best_opportunity_this_cycle[1].score:
                best_opportunity_this_cycle = (state, opportunity, history)

        if best_opportunity_this_cycle is not None:
            state, opportunity, history = best_opportunity_this_cycle
            entry_price = state.price_yes if opportunity.side == Side.YES else state.price_no
            volatility = history.realized_volatility(15)
            sizing = self.risk_manager.evaluate_position_size(
                self.portfolio,
                state,
                entry_price,
                opportunity.score,
                self._mark_to_market_prices(latest_by_id),
                volatility,
            )
            if sizing.approved:
                result = self.execution.simulate_market_order(
                    state, opportunity.side, OrderAction.BUY, sizing.notional_eur
                )
                if not result.rejected and result.quantity > 0:
                    strategy_names = ",".join(opportunity.contributing_strategies) or "inconnue"
                    self.portfolio.open_position(
                        market_id=state.market_id,
                        side=opportunity.side,
                        quantity=result.quantity,
                        entry_price=result.executed_price,
                        notional_eur=sizing.notional_eur,
                        fee_eur=result.fee_eur,
                        timestamp=state.timestamp,
                        strategy=strategy_names,
                        stop_loss_price=sizing.stop_loss_price,
                        take_profit_price=sizing.take_profit_price,
                    )
                    n_opened += 1
                    if self.db:
                        self.db.save_trade(
                            run_id=self.run_id,
                            timestamp=state.timestamp,
                            market_id=state.market_id,
                            strategy=strategy_names,
                            side=opportunity.side,
                            action=OrderAction.BUY,
                            quantity=result.quantity,
                            requested_price=result.requested_price,
                            executed_price=result.executed_price,
                            fee_eur=result.fee_eur,
                            slippage_eur=result.slippage_eur,
                            opportunity_score=opportunity.score,
                        )

        equity = self.portfolio.total_equity(self._mark_to_market_prices(latest_by_id))
        logger.info(
            "cycle_paper_trading_termine",
            run_id=self.run_id,
            marches_analyses=len(latest_by_id),
            positions_ouvertes=n_opened,
            positions_fermees=n_closed,
            equity=round(equity, 4),
        )

        return {
            "status": "ok",
            "marches_analyses": len(latest_by_id),
            "positions_ouvertes": n_opened,
            "positions_fermees": n_closed,
            "equity": equity,
            "aucune_opportunite": best_opportunity_this_cycle is None and n_opened == 0,
        }

    def run_loop(self, max_cycles: int | None = None) -> None:
        """Boucle infinie (ou bornée à `max_cycles`) : un cycle toutes les `cycle_minutes` minutes."""
        cycle_count = 0
        while max_cycles is None or cycle_count < max_cycles:
            self.run_cycle()
            cycle_count += 1
            if max_cycles is None or cycle_count < max_cycles:
                time.sleep(self.cycle_minutes * 60)

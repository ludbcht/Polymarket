"""Gestion du risque : sizing des positions, limites d'exposition, stops dynamiques.

Toutes les limites (risque par position, exposition totale, nombre de positions
simultanées) sont contraignantes : le moteur de décision ne peut jamais les outrepasser.
"""

from __future__ import annotations

from dataclasses import dataclass

from polyquant.backtest.portfolio import Portfolio
from polyquant.config import get_settings
from polyquant.data.models import MarketState
from polyquant.logging_config import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class PositionSizingDecision:
    approved: bool
    notional_eur: float
    reason: str
    stop_loss_price: float | None = None
    take_profit_price: float | None = None


class RiskManager:
    """Applique les règles de gestion du risque avant toute ouverture de position."""

    def __init__(
        self,
        max_risk_per_position_pct: float | None = None,
        max_total_exposure_pct: float | None = None,
        max_concurrent_positions: int | None = None,
        stop_loss_pct: float | None = None,
        take_profit_pct: float | None = None,
        volatility_reduction_threshold: float | None = None,
    ) -> None:
        settings = get_settings()
        self.max_risk_per_position_pct = (
            max_risk_per_position_pct
            if max_risk_per_position_pct is not None
            else settings.max_risk_per_position_pct
        )
        self.max_total_exposure_pct = (
            max_total_exposure_pct if max_total_exposure_pct is not None else settings.max_total_exposure_pct
        )
        self.max_concurrent_positions = (
            max_concurrent_positions
            if max_concurrent_positions is not None
            else settings.max_concurrent_positions
        )
        self.stop_loss_pct = stop_loss_pct if stop_loss_pct is not None else settings.stop_loss_pct
        self.take_profit_pct = take_profit_pct if take_profit_pct is not None else settings.take_profit_pct
        self.volatility_reduction_threshold = (
            volatility_reduction_threshold
            if volatility_reduction_threshold is not None
            else settings.volatility_reduction_threshold
        )

    def evaluate_position_size(
        self,
        portfolio: Portfolio,
        market: MarketState,
        entry_price: float,
        opportunity_score: float,
        current_prices: dict[str, float],
        realized_volatility: float | None = None,
    ) -> PositionSizingDecision:
        """Détermine si une position peut être ouverte et avec quelle taille."""
        equity = portfolio.total_equity(current_prices)

        if len(portfolio.positions) >= self.max_concurrent_positions:
            return PositionSizingDecision(False, 0.0, "nombre_max_positions_atteint")

        if market.market_id in portfolio.positions:
            return PositionSizingDecision(False, 0.0, "position_deja_ouverte_sur_ce_marche")

        # Taille de base : risque maximal par position, ajusté par la conviction du score.
        max_risk_eur = equity * self.max_risk_per_position_pct
        conviction_factor = min(max(opportunity_score, 0.0), 1.0)
        notional_eur = max_risk_eur * conviction_factor / max(self.stop_loss_pct, 1e-6)
        notional_eur = min(notional_eur, max_risk_eur / max(self.stop_loss_pct, 1e-6))

        # Réduction automatique en cas de volatilité élevée.
        if realized_volatility is not None and realized_volatility > self.volatility_reduction_threshold:
            reduction_factor = self.volatility_reduction_threshold / realized_volatility
            notional_eur *= max(0.1, min(reduction_factor, 1.0))
            logger.info(
                "reduction_taille_volatilite",
                market_id=market.market_id,
                volatilite=round(realized_volatility, 4),
                facteur=round(reduction_factor, 3),
            )

        # Vérification de l'exposition totale maximale.
        current_exposure = portfolio.total_exposure(current_prices)
        max_exposure_eur = equity * self.max_total_exposure_pct
        available_exposure = max_exposure_eur - current_exposure
        if available_exposure <= 0:
            return PositionSizingDecision(False, 0.0, "exposition_totale_maximale_atteinte")
        notional_eur = min(notional_eur, available_exposure)

        # Vérification du cash disponible.
        notional_eur = min(notional_eur, portfolio.cash * 0.98)  # marge de sécurité pour les frais

        if notional_eur <= 0.5:  # taille minimale non triviale (en euros)
            return PositionSizingDecision(False, 0.0, "taille_de_position_trop_faible")

        stop_loss_price = entry_price * (1 - self.stop_loss_pct)
        take_profit_price = entry_price * (1 + self.take_profit_pct)

        return PositionSizingDecision(
            approved=True,
            notional_eur=notional_eur,
            reason="approuve",
            stop_loss_price=max(0.001, stop_loss_price),
            take_profit_price=min(0.999, take_profit_price),
        )

    @staticmethod
    def should_exit_on_stops(current_price: float, stop_loss: float | None, take_profit: float | None) -> str | None:
        """Retourne la raison de sortie ('stop_loss' / 'take_profit') si un seuil est franchi."""
        if stop_loss is not None and current_price <= stop_loss:
            return "stop_loss"
        if take_profit is not None and current_price >= take_profit:
            return "take_profit"
        return None

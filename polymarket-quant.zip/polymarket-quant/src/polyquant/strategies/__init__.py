"""Registre central des stratégies disponibles dans le système."""

from __future__ import annotations

from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal
from polyquant.strategies.market_making import MarketMakingStrategy
from polyquant.strategies.mean_reversion import MeanReversionStrategy
from polyquant.strategies.momentum import MomentumStrategy
from polyquant.strategies.probability_shock import ProbabilityShockStrategy
from polyquant.strategies.ranking_allocator import RankingAllocatorStrategy
from polyquant.strategies.volume_anomaly import VolumeAnomalyStrategy

__all__ = [
    "MarketHistory",
    "Strategy",
    "StrategySignal",
    "MomentumStrategy",
    "MeanReversionStrategy",
    "VolumeAnomalyStrategy",
    "ProbabilityShockStrategy",
    "MarketMakingStrategy",
    "RankingAllocatorStrategy",
    "default_strategy_registry",
]


def default_strategy_registry() -> list[Strategy]:
    """Instancie l'ensemble des stratégies A à F avec leurs paramètres par défaut."""
    return [
        MomentumStrategy(),
        MeanReversionStrategy(),
        VolumeAnomalyStrategy(),
        ProbabilityShockStrategy(),
        MarketMakingStrategy(),
        RankingAllocatorStrategy(),
    ]

"""Interface commune à toutes les stratégies + structure de signal produite."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime

from polyquant.data.models import MarketState, Side


@dataclass(frozen=True, slots=True)
class MarketHistory:
    """Fenêtre glissante d'historique récent pour un marché, utilisée par les stratégies."""

    market_id: str
    states: list[MarketState] = field(default_factory=list)

    @property
    def latest(self) -> MarketState | None:
        return self.states[-1] if self.states else None

    def price_change(self, lookback: int) -> float | None:
        """Variation du prix YES sur les `lookback` derniers points (en points de probabilité)."""
        if len(self.states) <= lookback:
            return None
        current = self.states[-1].price_yes
        past = self.states[-1 - lookback].price_yes
        return current - past

    def volume_zscore(self, window: int = 20) -> float | None:
        """Z-score du volume courant par rapport à sa moyenne/écart-type récents."""
        if len(self.states) < window + 1:
            return None
        recent = [s.volume for s in self.states[-(window + 1) : -1]]
        mean = sum(recent) / len(recent)
        variance = sum((v - mean) ** 2 for v in recent) / len(recent)
        std = variance**0.5
        if std == 0:
            return 0.0
        return (self.states[-1].volume - mean) / std

    def realized_volatility(self, window: int = 20) -> float | None:
        """Volatilité réalisée (écart-type des variations de prix) sur la fenêtre."""
        if len(self.states) < window + 1:
            return None
        prices = [s.price_yes for s in self.states[-(window + 1) :]]
        diffs = [prices[i] - prices[i - 1] for i in range(1, len(prices))]
        mean_diff = sum(diffs) / len(diffs)
        variance = sum((d - mean_diff) ** 2 for d in diffs) / len(diffs)
        return variance**0.5


@dataclass(frozen=True, slots=True)
class StrategySignal:
    """Signal produit par une stratégie pour un marché donné."""

    strategy_name: str
    market_id: str
    timestamp: datetime
    side: Side
    strength: float  # dans [0, 1] : force/conviction du signal
    rationale: str

    def __post_init__(self) -> None:
        if not 0.0 <= self.strength <= 1.0:
            raise ValueError(f"strength doit être dans [0, 1], reçu {self.strength}")


class Strategy(ABC):
    """Classe de base pour toutes les stratégies de génération de signaux."""

    name: str = "base"

    @abstractmethod
    def generate_signal(self, history: MarketHistory) -> StrategySignal | None:
        """Analyse l'historique d'un marché et retourne un signal, ou None si pas d'opportunité."""
        raise NotImplementedError

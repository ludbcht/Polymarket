"""Stratégie E — Market making simulé.

Ne parie pas directionnellement : capture le spread bid/ask sur des marchés stables
(faible volatilité, spread suffisamment large pour être rentable après frais). Le signal
est émis du côté sous-évalué par rapport au mid-price théorique, avec une conviction
proportionnelle à la largeur du spread disponible.
"""

from __future__ import annotations

from datetime import UTC, datetime

from polyquant.data.models import Side
from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal


class MarketMakingStrategy(Strategy):
    name = "market_making_simule"

    def __init__(
        self,
        min_spread: float = 0.02,
        max_volatility: float = 0.01,
        volatility_window: int = 15,
    ) -> None:
        self.min_spread = min_spread
        self.max_volatility = max_volatility
        self.volatility_window = volatility_window

    def generate_signal(self, history: MarketHistory) -> StrategySignal | None:
        latest = history.latest
        if latest is None:
            return None

        # Le market making n'a de sens que sur un marché calme : spread suffisant, faible volatilité.
        if latest.spread < self.min_spread:
            return None

        volatility = history.realized_volatility(self.volatility_window)
        if volatility is None or volatility > self.max_volatility:
            return None

        # Position légèrement du côté YES (achat au bid théorique), la stratégie est symétrique
        # et vise à capter le spread plutôt qu'à parier sur une direction.
        strength = min(latest.spread / (self.min_spread * 3), 1.0)

        return StrategySignal(
            strategy_name=self.name,
            market_id=history.market_id,
            timestamp=latest.timestamp or datetime.now(UTC),
            side=Side.YES,
            strength=strength,
            rationale=(
                f"Marché calme (volatilité={volatility:.4f}) avec spread captable "
                f"({latest.spread:.3f})"
            ),
        )

"""Stratégie B — Retour à la moyenne.

Détecte un écart excessif et rapide du prix par rapport à sa moyenne mobile récente,
sans justification de volume proportionnelle, et parie sur un retour vers la moyenne.
"""

from __future__ import annotations

from datetime import UTC, datetime

from polyquant.data.models import Side
from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal


class MeanReversionStrategy(Strategy):
    name = "retour_moyenne"

    def __init__(
        self,
        window: int = 20,
        deviation_threshold: float = 0.06,
        max_volume_zscore_for_reversion: float = 1.0,
    ) -> None:
        self.window = window
        self.deviation_threshold = deviation_threshold
        self.max_volume_zscore_for_reversion = max_volume_zscore_for_reversion

    def generate_signal(self, history: MarketHistory) -> StrategySignal | None:
        latest = history.latest
        if latest is None or len(history.states) < self.window + 1:
            return None

        recent_prices = [s.price_yes for s in history.states[-(self.window + 1) : -1]]
        moving_avg = sum(recent_prices) / len(recent_prices)
        deviation = latest.price_yes - moving_avg

        if abs(deviation) < self.deviation_threshold:
            return None

        # Un écart accompagné d'un pic de volume est probablement une info nouvelle légitime,
        # pas une anomalie : on évite alors de parier contre le mouvement.
        vol_z = history.volume_zscore(self.window)
        if vol_z is not None and vol_z > self.max_volume_zscore_for_reversion:
            return None

        # Le prix est trop haut -> on parie sur NO (retour vers le bas), et inversement.
        side = Side.NO if deviation > 0 else Side.YES
        strength = min(abs(deviation) / (self.deviation_threshold * 2.5), 1.0)

        return StrategySignal(
            strategy_name=self.name,
            market_id=history.market_id,
            timestamp=latest.timestamp or datetime.now(UTC),
            side=side,
            strength=strength,
            rationale=(
                f"Écart de {deviation:+.3f} vs moyenne mobile {self.window} pts "
                f"({moving_avg:.3f}), sans confirmation de volume"
            ),
        )

"""Stratégie A — Momentum probabiliste.

Détecte une tendance directionnelle persistante de la probabilité implicite (prix YES)
sur plusieurs horizons, et parie sur sa continuation à court terme.
"""

from __future__ import annotations

from datetime import UTC, datetime

from polyquant.data.models import Side
from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal


class MomentumStrategy(Strategy):
    name = "momentum_probabiliste"

    def __init__(
        self,
        short_lookback: int = 3,
        long_lookback: int = 12,
        min_move_threshold: float = 0.03,
    ) -> None:
        self.short_lookback = short_lookback
        self.long_lookback = long_lookback
        self.min_move_threshold = min_move_threshold

    def generate_signal(self, history: MarketHistory) -> StrategySignal | None:
        latest = history.latest
        if latest is None:
            return None

        short_move = history.price_change(self.short_lookback)
        long_move = history.price_change(self.long_lookback)
        if short_move is None or long_move is None:
            return None

        # Le momentum doit être cohérent sur les deux horizons (même signe) et significatif.
        if short_move * long_move <= 0:
            return None
        if abs(short_move) < self.min_move_threshold:
            return None

        side = Side.YES if short_move > 0 else Side.NO
        magnitude = min(abs(short_move) + abs(long_move) / 2, 0.5)
        strength = min(magnitude / 0.15, 1.0)

        return StrategySignal(
            strategy_name=self.name,
            market_id=history.market_id,
            timestamp=latest.timestamp or datetime.now(UTC),
            side=side,
            strength=strength,
            rationale=(
                f"Momentum cohérent: variation court terme={short_move:+.3f}, "
                f"long terme={long_move:+.3f}"
            ),
        )

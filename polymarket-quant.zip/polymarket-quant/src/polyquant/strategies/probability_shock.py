"""Stratégie D — Détection de mouvements brutaux de probabilité (choc/gap).

Détecte un saut de prix anormalement rapide sur un très court horizon (1 à 2 cycles),
signature typique d'une information nouvelle (news, résultat, déclaration). La stratégie
suit la direction du choc, en misant sur la poursuite du mouvement à très court terme.
"""

from __future__ import annotations

from datetime import UTC, datetime

from polyquant.data.models import Side
from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal


class ProbabilityShockStrategy(Strategy):
    name = "choc_probabilite"

    def __init__(self, shock_lookback: int = 1, shock_threshold: float = 0.08) -> None:
        self.shock_lookback = shock_lookback
        self.shock_threshold = shock_threshold

    def generate_signal(self, history: MarketHistory) -> StrategySignal | None:
        latest = history.latest
        if latest is None:
            return None

        move = history.price_change(self.shock_lookback)
        if move is None or abs(move) < self.shock_threshold:
            return None

        side = Side.YES if move > 0 else Side.NO
        strength = min(abs(move) / (self.shock_threshold * 2), 1.0)

        return StrategySignal(
            strategy_name=self.name,
            market_id=history.market_id,
            timestamp=latest.timestamp or datetime.now(UTC),
            side=side,
            strength=strength,
            rationale=f"Choc de probabilité: {move:+.3f} en {self.shock_lookback} cycle(s)",
        )

"""Stratégie F — Classement des marchés et allocation vers les opportunités les plus attractives.

Contrairement aux stratégies A-E qui analysent un marché isolément, celle-ci calcule un
score d'attractivité relatif (volume, liquidité, spread, volatilité) sur l'ensemble de
l'univers de marchés disponibles à un instant donné, et ne génère un signal que pour les
marchés les mieux classés (top percentile), dans la direction du momentum récent.
"""

from __future__ import annotations

from datetime import UTC, datetime

from polyquant.data.models import Side
from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal


class RankingAllocatorStrategy(Strategy):
    name = "classement_allocation"

    def __init__(self, top_fraction: float = 0.2, min_momentum: float = 0.01) -> None:
        self.top_fraction = top_fraction
        self.min_momentum = min_momentum

    def _attractiveness_score(self, history: MarketHistory) -> float | None:
        latest = history.latest
        if latest is None or len(history.states) < 20:
            return None

        volatility = history.realized_volatility(15) or 0.0
        # Score composite normalisé de façon heuristique : volume et liquidité élevés sont
        # positifs, spread élevé est négatif (coût d'exécution), volatilité modérée est
        # positive (ni marché mort, ni chaos incontrôlable).
        volume_score = min(latest.volume / 100_000, 1.0)
        liquidity_score = min(latest.liquidity / 50_000, 1.0)
        spread_penalty = min(latest.spread / 0.1, 1.0)
        volatility_score = 1.0 - abs(volatility - 0.02) / 0.02 if volatility <= 0.04 else 0.0
        volatility_score = max(0.0, volatility_score)

        return (
            0.35 * volume_score
            + 0.30 * liquidity_score
            + 0.20 * volatility_score
            - 0.15 * spread_penalty
        )

    def generate_signal(self, history: MarketHistory) -> StrategySignal | None:
        """Génère un signal pour un marché unique. Le filtrage relatif (top percentile) doit
        être appliqué en amont par `rank_universe` sur l'ensemble de l'univers de marchés.
        """
        latest = history.latest
        if latest is None:
            return None

        score = self._attractiveness_score(history)
        if score is None or score <= 0:
            return None

        momentum = history.price_change(5)
        if momentum is None or abs(momentum) < self.min_momentum:
            return None

        side = Side.YES if momentum > 0 else Side.NO
        return StrategySignal(
            strategy_name=self.name,
            market_id=history.market_id,
            timestamp=latest.timestamp or datetime.now(UTC),
            side=side,
            strength=min(max(score, 0.0), 1.0),
            rationale=f"Score d'attractivité={score:.3f}, momentum confirmé={momentum:+.3f}",
        )

    def rank_universe(self, histories: list[MarketHistory]) -> list[MarketHistory]:
        """Retourne le sous-ensemble des marchés dans le top `top_fraction` par attractivité."""
        scored = [
            (h, self._attractiveness_score(h))
            for h in histories
            if self._attractiveness_score(h) is not None
        ]
        scored.sort(key=lambda pair: pair[1] or 0.0, reverse=True)
        n_top = max(1, int(len(scored) * self.top_fraction))
        return [h for h, _ in scored[:n_top]]

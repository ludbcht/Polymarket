"""Stratégie C — Détection d'anomalies de volume.

Un pic de volume statistiquement anormal précède souvent un mouvement de prix
(information nouvelle en cours d'absorption par le marché). La stratégie suit la
direction du prix au moment du pic.
"""

from __future__ import annotations

from datetime import UTC, datetime

from polyquant.data.models import Side
from polyquant.strategies.base import MarketHistory, Strategy, StrategySignal


class VolumeAnomalyStrategy(Strategy):
    name = "anomalie_volume"

    def __init__(self, window: int = 20, zscore_threshold: float = 2.5, confirm_lookback: int = 2) -> None:
        self.window = window
        self.zscore_threshold = zscore_threshold
        self.confirm_lookback = confirm_lookback

    def generate_signal(self, history: MarketHistory) -> StrategySignal | None:
        latest = history.latest
        if latest is None:
            return None

        vol_z = history.volume_zscore(self.window)
        if vol_z is None or vol_z < self.zscore_threshold:
            return None

        price_move = history.price_change(self.confirm_lookback)
        if price_move is None or abs(price_move) < 0.005:
            return None

        side = Side.YES if price_move > 0 else Side.NO
        strength = min(vol_z / (self.zscore_threshold * 2), 1.0)

        return StrategySignal(
            strategy_name=self.name,
            market_id=history.market_id,
            timestamp=latest.timestamp or datetime.now(UTC),
            side=side,
            strength=strength,
            rationale=(
                f"Pic de volume anormal (z-score={vol_z:.2f}) confirmé par un mouvement "
                f"de prix de {price_move:+.3f}"
            ),
        )

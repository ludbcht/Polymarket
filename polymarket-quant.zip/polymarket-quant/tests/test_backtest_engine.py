from __future__ import annotations

from polyquant.backtest.engine import BacktestConfig, BacktestEngine
from polyquant.data.database import Database
from polyquant.data.replay import HistoricalReplayEngine
from polyquant.data.synthetic import generate_synthetic_universe
from polyquant.strategies import default_strategy_registry


def test_backtest_runs_end_to_end_without_ml(tmp_path) -> None:
    db_path = tmp_path / "test.db"
    db = Database(database_url=f"sqlite:///{db_path}")
    db.create_schema()

    states = generate_synthetic_universe(n_markets=5, n_points=80, seed=1, shock_probability=0.05)
    db.save_snapshots(states)

    cycles = HistoricalReplayEngine(db).load()
    assert len(cycles) == 80

    config = BacktestConfig(initial_capital=100.0, strategies=default_strategy_registry(), use_ml=False)
    engine = BacktestEngine(config)
    result = engine.run(cycles)

    assert result.performance.initial_capital == 100.0
    assert result.performance.final_equity > 0  # jamais de capital négatif
    assert result.n_signals_traded <= result.n_signals_generated
    # Le système ne doit jamais ouvrir plus de positions simultanées que la limite de risque.
    assert len(result.portfolio.positions) <= 5


def test_backtest_never_exceeds_max_concurrent_positions(tmp_path) -> None:
    from polyquant.risk.manager import RiskManager

    db_path = tmp_path / "test.db"
    db = Database(database_url=f"sqlite:///{db_path}")
    db.create_schema()

    states = generate_synthetic_universe(n_markets=20, n_points=150, seed=2, shock_probability=0.1)
    db.save_snapshots(states)
    cycles = HistoricalReplayEngine(db).load()

    config = BacktestConfig(initial_capital=100.0, strategies=default_strategy_registry(), use_ml=False)
    risk_manager = RiskManager(max_concurrent_positions=3)
    engine = BacktestEngine(config, risk_manager=risk_manager)
    result = engine.run(cycles)

    assert len(result.portfolio.positions) <= 3


def test_backtest_with_empty_cycles_returns_initial_capital() -> None:
    config = BacktestConfig(initial_capital=100.0, strategies=default_strategy_registry(), use_ml=False)
    engine = BacktestEngine(config)
    result = engine.run([])
    assert result.performance.final_equity == 100.0
    assert result.performance.n_trades == 0

from __future__ import annotations

from polyquant.config import Settings


def test_default_settings_load() -> None:
    settings = Settings(_env_file=None)
    assert settings.initial_capital_eur == 100.0
    assert settings.max_concurrent_positions == 5


def test_decision_weights_sum_to_one_by_default() -> None:
    settings = Settings(_env_file=None)
    assert abs(settings.decision_weights_sum - 1.0) < 1e-9


def test_risk_pct_validation_rejects_out_of_bounds() -> None:
    import pytest

    with pytest.raises(ValueError):
        Settings(_env_file=None, max_risk_per_position_pct=1.5)

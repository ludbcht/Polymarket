from __future__ import annotations

from datetime import UTC, datetime

from polyquant.backtest.execution import ExecutionSimulator
from polyquant.data.models import MarketState, OrderAction, Side


def make_market(**overrides: object) -> MarketState:
    defaults = dict(
        market_id="m1",
        question="q",
        category="test",
        timestamp=datetime.now(UTC),
        volume=10_000.0,
        liquidity=5_000.0,
        price_yes=0.5,
        price_no=0.5,
        spread=0.02,
        order_book_depth=1_000.0,
    )
    defaults.update(overrides)
    return MarketState(**defaults)  # type: ignore[arg-type]


def test_buy_order_executes_above_reference_price() -> None:
    sim = ExecutionSimulator(taker_fee_bps=200, slippage_bps=50)
    market = make_market()
    result = sim.simulate_market_order(market, Side.YES, OrderAction.BUY, notional_eur=10.0)
    assert not result.rejected
    assert result.executed_price > result.requested_price
    assert result.fee_eur > 0
    assert result.quantity > 0


def test_sell_order_executes_below_reference_price() -> None:
    sim = ExecutionSimulator(taker_fee_bps=200, slippage_bps=50)
    market = make_market()
    result = sim.simulate_market_order(market, Side.YES, OrderAction.SELL, notional_eur=10.0)
    assert not result.rejected
    assert result.executed_price < result.requested_price


def test_order_rejected_when_exceeding_depth_limit() -> None:
    sim = ExecutionSimulator(max_depth_impact=0.25)
    market = make_market(order_book_depth=10.0)
    result = sim.simulate_market_order(market, Side.YES, OrderAction.BUY, notional_eur=1000.0)
    assert result.rejected
    assert result.rejection_reason == "liquidite_insuffisante"


def test_fee_scales_with_notional() -> None:
    sim = ExecutionSimulator(taker_fee_bps=200)
    market = make_market()
    small = sim.simulate_market_order(market, Side.YES, OrderAction.BUY, notional_eur=10.0)
    large = sim.simulate_market_order(market, Side.YES, OrderAction.BUY, notional_eur=20.0)
    assert large.fee_eur > small.fee_eur


def test_rejected_on_price_out_of_bounds() -> None:
    sim = ExecutionSimulator()
    market = make_market(price_yes=0.0, price_no=1.0)
    result = sim.simulate_market_order(market, Side.YES, OrderAction.BUY, notional_eur=5.0)
    assert result.rejected
    assert result.rejection_reason == "prix_hors_bornes"

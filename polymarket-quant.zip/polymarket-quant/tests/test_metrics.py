from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from polyquant.backtest.metrics import (
    compute_expectancy,
    compute_max_drawdown_pct,
    compute_profit_factor,
    compute_win_rate_pct,
    generate_performance_report,
)
from polyquant.backtest.portfolio import ClosedTrade
from polyquant.data.models import Side


def make_trade(pnl: float) -> ClosedTrade:
    now = datetime.now(UTC)
    return ClosedTrade(
        market_id="m1",
        side=Side.YES,
        strategy="test",
        quantity=10.0,
        entry_price=0.5,
        exit_price=0.5 + pnl / 10.0,
        entry_timestamp=now,
        exit_timestamp=now,
        realized_pnl=pnl,
        fees_paid=0.1,
        exit_reason="test",
    )


def test_max_drawdown_from_flat_curve_is_zero() -> None:
    now = datetime.now(UTC)
    curve = [(now + timedelta(minutes=i), 100.0) for i in range(5)]
    assert compute_max_drawdown_pct(curve) == 0.0


def test_max_drawdown_detects_peak_to_trough() -> None:
    now = datetime.now(UTC)
    curve = [
        (now, 100.0),
        (now + timedelta(minutes=1), 120.0),
        (now + timedelta(minutes=2), 90.0),
        (now + timedelta(minutes=3), 110.0),
    ]
    dd = compute_max_drawdown_pct(curve)
    assert dd == pytest.approx((120 - 90) / 120 * 100)


def test_profit_factor_with_mixed_trades() -> None:
    trades = [make_trade(10.0), make_trade(-5.0), make_trade(5.0)]
    pf = compute_profit_factor(trades)
    assert pf == pytest.approx(15.0 / 5.0)


def test_profit_factor_with_no_losses_is_infinite() -> None:
    trades = [make_trade(10.0), make_trade(5.0)]
    assert compute_profit_factor(trades) == float("inf")


def test_win_rate_and_expectancy() -> None:
    trades = [make_trade(10.0), make_trade(-5.0), make_trade(-2.0)]
    assert compute_win_rate_pct(trades) == pytest.approx(100 / 3)
    assert compute_expectancy(trades) == pytest.approx((10 - 5 - 2) / 3)


def test_generate_performance_report_end_to_end() -> None:
    now = datetime.now(UTC)
    curve = [(now + timedelta(minutes=i * 5), 100.0 + i) for i in range(20)]
    trades = [make_trade(5.0), make_trade(-2.0)]
    report = generate_performance_report(100.0, curve, trades, total_fees_paid=1.0)
    assert report.initial_capital == 100.0
    assert report.n_trades == 2
    assert report.total_fees_paid == 1.0
    assert report.final_equity == curve[-1][1]

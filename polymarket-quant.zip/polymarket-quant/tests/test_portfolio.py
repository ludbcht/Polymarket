from __future__ import annotations

from datetime import UTC, datetime

import pytest

from polyquant.backtest.portfolio import Portfolio
from polyquant.data.models import Side


def test_portfolio_starts_with_full_cash() -> None:
    portfolio = Portfolio(initial_capital=100.0)
    assert portfolio.cash == 100.0
    assert portfolio.positions == {}


def test_open_position_debits_cash_and_fees() -> None:
    portfolio = Portfolio(initial_capital=100.0)
    portfolio.open_position(
        market_id="m1",
        side=Side.YES,
        quantity=20.0,
        entry_price=0.5,
        notional_eur=10.0,
        fee_eur=0.2,
        timestamp=datetime.now(UTC),
        strategy="test",
    )
    assert portfolio.cash == pytest.approx(89.8)
    assert "m1" in portfolio.positions
    assert portfolio.total_fees_paid == pytest.approx(0.2)


def test_cannot_open_duplicate_position_on_same_market() -> None:
    portfolio = Portfolio(initial_capital=100.0)
    portfolio.open_position(
        market_id="m1",
        side=Side.YES,
        quantity=10.0,
        entry_price=0.5,
        notional_eur=5.0,
        fee_eur=0.1,
        timestamp=datetime.now(UTC),
        strategy="test",
    )
    with pytest.raises(ValueError):
        portfolio.open_position(
            market_id="m1",
            side=Side.YES,
            quantity=10.0,
            entry_price=0.5,
            notional_eur=5.0,
            fee_eur=0.1,
            timestamp=datetime.now(UTC),
            strategy="test",
        )


def test_cannot_open_position_with_insufficient_cash() -> None:
    portfolio = Portfolio(initial_capital=10.0)
    with pytest.raises(ValueError):
        portfolio.open_position(
            market_id="m1",
            side=Side.YES,
            quantity=1000.0,
            entry_price=0.5,
            notional_eur=500.0,
            fee_eur=1.0,
            timestamp=datetime.now(UTC),
            strategy="test",
        )


def test_close_position_computes_realized_pnl() -> None:
    portfolio = Portfolio(initial_capital=100.0)
    portfolio.open_position(
        market_id="m1",
        side=Side.YES,
        quantity=20.0,
        entry_price=0.5,
        notional_eur=10.0,
        fee_eur=0.0,
        timestamp=datetime.now(UTC),
        strategy="test",
    )
    trade = portfolio.close_position(
        market_id="m1", exit_price=0.6, fee_eur=0.0, timestamp=datetime.now(UTC), reason="take_profit"
    )
    assert trade.realized_pnl == pytest.approx((0.6 - 0.5) * 20.0)
    assert "m1" not in portfolio.positions
    assert portfolio.cash == pytest.approx(90.0 + 0.6 * 20.0)


def test_total_exposure_and_equity() -> None:
    portfolio = Portfolio(initial_capital=100.0)
    portfolio.open_position(
        market_id="m1",
        side=Side.YES,
        quantity=20.0,
        entry_price=0.5,
        notional_eur=10.0,
        fee_eur=0.0,
        timestamp=datetime.now(UTC),
        strategy="test",
    )
    current_prices = {"m1": 0.55}
    assert portfolio.total_exposure(current_prices) == pytest.approx(11.0)
    assert portfolio.total_equity(current_prices) == pytest.approx(90.0 + 11.0)
    assert portfolio.unrealized_pnl_total(current_prices) == pytest.approx(1.0)

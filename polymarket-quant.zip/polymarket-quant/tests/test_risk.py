from __future__ import annotations

from datetime import UTC, datetime

from polyquant.backtest.portfolio import Portfolio
from polyquant.data.models import MarketState, Side
from polyquant.risk.manager import RiskManager


def make_market(price: float = 0.5) -> MarketState:
    return MarketState(
        market_id="m1",
        question="q",
        category="test",
        timestamp=datetime.now(UTC),
        volume=10_000.0,
        liquidity=5_000.0,
        price_yes=price,
        price_no=1 - price,
        spread=0.02,
        order_book_depth=1_000.0,
    )


def test_position_size_respects_max_risk_per_position() -> None:
    rm = RiskManager(max_risk_per_position_pct=0.01, stop_loss_pct=0.10, max_concurrent_positions=5)
    portfolio = Portfolio(initial_capital=100.0)
    market = make_market()
    decision = rm.evaluate_position_size(portfolio, market, 0.5, opportunity_score=1.0, current_prices={})
    assert decision.approved
    # Perte maximale théorique si le stop est touché ne doit pas dépasser 1% du capital.
    max_loss = decision.notional_eur * rm.stop_loss_pct
    assert max_loss <= 100.0 * 0.01 + 1e-6


def test_rejects_when_max_concurrent_positions_reached() -> None:
    rm = RiskManager(max_concurrent_positions=1)
    portfolio = Portfolio(initial_capital=100.0)
    portfolio.open_position(
        market_id="other",
        side=Side.YES,
        quantity=1.0,
        entry_price=0.5,
        notional_eur=1.0,
        fee_eur=0.0,
        timestamp=datetime.now(UTC),
        strategy="test",
    )
    market = make_market()
    decision = rm.evaluate_position_size(portfolio, market, 0.5, opportunity_score=1.0, current_prices={})
    assert not decision.approved
    assert decision.reason == "nombre_max_positions_atteint"


def test_rejects_duplicate_position_on_same_market() -> None:
    rm = RiskManager()
    portfolio = Portfolio(initial_capital=100.0)
    portfolio.open_position(
        market_id="m1",
        side=Side.YES,
        quantity=1.0,
        entry_price=0.5,
        notional_eur=1.0,
        fee_eur=0.0,
        timestamp=datetime.now(UTC),
        strategy="test",
    )
    market = make_market()
    decision = rm.evaluate_position_size(portfolio, market, 0.5, opportunity_score=1.0, current_prices={})
    assert not decision.approved
    assert decision.reason == "position_deja_ouverte_sur_ce_marche"


def test_volatility_reduces_position_size() -> None:
    rm = RiskManager(volatility_reduction_threshold=0.02, max_risk_per_position_pct=0.05, stop_loss_pct=0.1)
    portfolio = Portfolio(initial_capital=100.0)
    market = make_market()

    calm = rm.evaluate_position_size(
        portfolio, market, 0.5, opportunity_score=1.0, current_prices={}, realized_volatility=0.01
    )
    volatile = rm.evaluate_position_size(
        portfolio, market, 0.5, opportunity_score=1.0, current_prices={}, realized_volatility=0.10
    )
    assert calm.approved and volatile.approved
    assert volatile.notional_eur < calm.notional_eur


def test_exit_on_stop_loss() -> None:
    reason = RiskManager.should_exit_on_stops(current_price=0.4, stop_loss=0.45, take_profit=0.7)
    assert reason == "stop_loss"


def test_exit_on_take_profit() -> None:
    reason = RiskManager.should_exit_on_stops(current_price=0.75, stop_loss=0.45, take_profit=0.7)
    assert reason == "take_profit"


def test_no_exit_within_bounds() -> None:
    reason = RiskManager.should_exit_on_stops(current_price=0.55, stop_loss=0.45, take_profit=0.7)
    assert reason is None

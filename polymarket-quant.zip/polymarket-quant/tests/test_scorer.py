from __future__ import annotations

from datetime import UTC, datetime

from polyquant.data.models import MarketState, Side
from polyquant.decision.scorer import DecisionScorer
from polyquant.strategies.base import StrategySignal


def make_market(volume: float = 100_000.0, liquidity: float = 50_000.0, spread: float = 0.01) -> MarketState:
    return MarketState(
        market_id="m1",
        question="q",
        category="test",
        timestamp=datetime.now(UTC),
        volume=volume,
        liquidity=liquidity,
        price_yes=0.5,
        price_no=0.5,
        spread=spread,
        order_book_depth=1_000.0,
    )


def make_signal(side: Side, strength: float, name: str = "s1") -> StrategySignal:
    return StrategySignal(
        strategy_name=name,
        market_id="m1",
        timestamp=datetime.now(UTC),
        side=side,
        strength=strength,
        rationale="test",
    )


def test_no_signals_returns_none() -> None:
    scorer = DecisionScorer()
    assert scorer.score(make_market(), []) is None


def test_strong_aligned_signals_produce_high_score() -> None:
    scorer = DecisionScorer(threshold=0.5)
    market = make_market()
    signals = [make_signal(Side.YES, 0.9, "s1"), make_signal(Side.YES, 0.8, "s2")]
    result = scorer.score(market, signals)
    assert result is not None
    assert result.side == Side.YES
    assert result.tradable


def test_conflicting_signals_produce_no_result() -> None:
    scorer = DecisionScorer()
    market = make_market()
    signals = [make_signal(Side.YES, 0.5, "s1"), make_signal(Side.NO, 0.5, "s2")]
    result = scorer.score(market, signals)
    assert result is None


def test_weak_market_conditions_can_prevent_tradability() -> None:
    scorer = DecisionScorer(threshold=0.9)
    market = make_market(volume=100.0, liquidity=100.0, spread=0.09)
    signals = [make_signal(Side.YES, 0.3, "s1")]
    result = scorer.score(market, signals)
    assert result is not None
    assert not result.tradable


def test_ml_probability_influences_score() -> None:
    scorer = DecisionScorer(weight_ml=0.5, weight_momentum=0.5, weight_volume=0, weight_liquidity=0, weight_spread=0)
    market = make_market()
    signals = [make_signal(Side.YES, 0.6, "s1")]

    low_ml = scorer.score(market, signals, ml_probability=0.1)
    high_ml = scorer.score(market, signals, ml_probability=0.9)
    assert low_ml is not None and high_ml is not None
    assert high_ml.score > low_ml.score

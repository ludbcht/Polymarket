from __future__ import annotations

from datetime import UTC, datetime, timedelta

from polyquant.data.models import MarketState, Side
from polyquant.strategies.base import MarketHistory
from polyquant.strategies.mean_reversion import MeanReversionStrategy
from polyquant.strategies.momentum import MomentumStrategy
from polyquant.strategies.probability_shock import ProbabilityShockStrategy
from polyquant.strategies.volume_anomaly import VolumeAnomalyStrategy


def make_state(i: int, price: float, volume: float = 1000.0, spread: float = 0.02) -> MarketState:
    return MarketState(
        market_id="m1",
        question="q",
        category="test",
        timestamp=datetime.now(UTC) + timedelta(minutes=5 * i),
        volume=volume,
        liquidity=5000.0,
        price_yes=price,
        price_no=1 - price,
        spread=spread,
        order_book_depth=1000.0,
    )


def test_momentum_strategy_detects_consistent_uptrend() -> None:
    strategy = MomentumStrategy(short_lookback=3, long_lookback=10, min_move_threshold=0.03)
    prices = [0.3 + 0.01 * i for i in range(15)]  # tendance haussière régulière
    states = [make_state(i, p) for i, p in enumerate(prices)]
    history = MarketHistory(market_id="m1", states=states)
    signal = strategy.generate_signal(history)
    assert signal is not None
    assert signal.side == Side.YES


def test_momentum_strategy_no_signal_on_flat_market() -> None:
    strategy = MomentumStrategy()
    states = [make_state(i, 0.5) for i in range(15)]
    history = MarketHistory(market_id="m1", states=states)
    assert strategy.generate_signal(history) is None


def test_mean_reversion_detects_overextension() -> None:
    strategy = MeanReversionStrategy(window=10, deviation_threshold=0.05)
    states = [make_state(i, 0.5, volume=1000.0) for i in range(10)]
    states.append(make_state(10, 0.65, volume=1000.0))  # écart brutal sans volume
    history = MarketHistory(market_id="m1", states=states)
    signal = strategy.generate_signal(history)
    assert signal is not None
    assert signal.side == Side.NO  # prix trop haut -> pari sur baisse


def test_probability_shock_detects_sudden_jump() -> None:
    strategy = ProbabilityShockStrategy(shock_lookback=1, shock_threshold=0.08)
    states = [make_state(0, 0.4), make_state(1, 0.55)]
    history = MarketHistory(market_id="m1", states=states)
    signal = strategy.generate_signal(history)
    assert signal is not None
    assert signal.side == Side.YES


def test_volume_anomaly_requires_both_volume_and_price_confirmation() -> None:
    strategy = VolumeAnomalyStrategy(window=10, zscore_threshold=2.0)
    states = [make_state(i, 0.5, volume=1000.0) for i in range(10)]
    # Gros pic de volume mais sans mouvement de prix -> pas de signal
    states.append(make_state(10, 0.5, volume=1000.0))
    history = MarketHistory(market_id="m1", states=states)
    assert strategy.generate_signal(history) is None


def test_strategy_signal_rejects_invalid_strength() -> None:
    import pytest

    from polyquant.strategies.base import StrategySignal

    with pytest.raises(ValueError):
        StrategySignal(
            strategy_name="test",
            market_id="m1",
            timestamp=datetime.now(UTC),
            side=Side.YES,
            strength=1.5,
            rationale="invalid",
        )
